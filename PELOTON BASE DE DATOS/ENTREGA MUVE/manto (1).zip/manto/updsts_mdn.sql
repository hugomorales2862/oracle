


(expression)  update statistics low for table armas

(expression)  update statistics low for table coc_planificar

(expression)  update statistics low for table escuelas

(expression)  update statistics low for table cursos

(expression)  update statistics low for table paises

(expression)  update statistics low for table meom

(expression)  update statistics low for table grados

(expression)  update statistics low for table asignaciones

(expression)  update statistics low for table menu_master

(expression)  update statistics low for table mfsub

(expression)  update statistics low for table mfsue_e

(expression)  update statistics low for table mfsue_o

(expression)  update statistics low for table mftro

(expression)  update statistics low for table pdinero

(expression)  update statistics low for table mfdep

(expression)  update statistics low for table banderas

(expression)  update statistics low for table sysmenus

(expression)  update statistics low for table sysmenuitems

(expression)  update statistics low for table tropabajas

(expression)  update statistics low for table tropa_sp

(expression)  update statistics low for table asig_plaza

(expression)  update statistics low for table permtropa

(expression)  update statistics low for table dep_mun

(expression)  update statistics low for table pcdtablr

(expression)  update statistics low for table cgdcolmr

(expression)  update statistics low for table cgdtablr

(expression)  update statistics low for table cgmcmndd

(expression)  update statistics low for table cgmcmndr

(expression)  update statistics low for table cgmmenud

(expression)  update statistics low for table cgmmposr

(expression)  update statistics low for table cgrrimgd

(expression)  update statistics low for table cgsscrnr

(expression)  update statistics low for table cgxsorcd

(expression)  update statistics low for table stxacknd

(expression)  update statistics low for table stxactnr

(expression)  update statistics low for table stxaddld

(expression)  update statistics low for table stxaddlr

(expression)  update statistics low for table stxcompr

(expression)  update statistics low for table stxerord

(expression)  update statistics low for table stxerorh

(expression)  update statistics low for table stxfiler

(expression)  update statistics low for table stxfiltr

(expression)  update statistics low for table stxfuncr

(expression)  update statistics low for table stxgropd

(expression)  update statistics low for table stxhelpd

(expression)  update statistics low for table stxhotkd

(expression)  update statistics low for table stxkeysr

(expression)  update statistics low for table stxlangr

(expression)  update statistics low for table stxmssgr

(expression)  update statistics low for table stxnoted

(expression)  update statistics low for table stxnvgtd

(expression)  update statistics low for table stxparmd

(expression)  update statistics low for table stxpermd

(expression)  update statistics low for table stxpermr

(expression)  update statistics low for table stxprogr

(expression)  update statistics low for table stxsecud

(expression)  update statistics low for table stxtodod

(expression)  update statistics low for table stxtxtdd

(expression)  update statistics low for table stxuniqc

(expression)  update statistics low for table cgsblobr

(expression)  update statistics low for table cgsclipr

(expression)  update statistics low for table cgscmdsd

(expression)  update statistics low for table cgscmdsr

(expression)  update statistics low for table cgsdpndd

(expression)  update statistics low for table cgsimged

(expression)  update statistics low for table cgsinptr

(expression)  update statistics low for table cgsstypr

(expression)  update statistics low for table cgstrigr

(expression)  update statistics low for table cgszoomr

(expression)  update statistics low for table cgxfnamr

(expression)  update statistics low for table cgxfsetd

(expression)  update statistics low for table cgxlkupr

(expression)  update statistics low for table cgxlntod

(expression)  update statistics low for table cgxmathr

(expression)  update statistics low for table stxparmh

(expression)  update statistics low for table ipm_fact

(expression)  update statistics low for table banejer_acc

(expression)  update statistics low for table pbienal

(expression)  update statistics low for table cgstrigd

(expression)  update statistics low for table sinefecto

(expression)  update statistics low for table partidas

(expression)  update statistics low for table noestan

(expression)  update statistics low for table empresas

(expression)  update statistics low for table fmasi

(expression)  update statistics low for table fmdes

(expression)  update statistics low for table syscolval

(expression)  update statistics low for table cgsifldd

(expression)  update statistics low for table disr

(expression)  update statistics low for table descuentos

(expression)  update statistics low for table permisos

(expression)  update statistics low for table hdareal

(expression)  update statistics low for table retencion

(expression)  update statistics low for table jefes

(expression)  update statistics low for table fuerza

(expression)  update statistics low for table nopagados

(expression)  update statistics low for table des_no_efec

(expression)  update statistics low for table tipo_docum

(expression)  update statistics low for table menus

(expression)  update statistics low for table usumenu

(expression)  update statistics low for table mcols

(expression)  update statistics low for table mreps

(expression)  update statistics low for table depmun

(expression)  update statistics low for table meop

(expression)  update statistics low for table fbitacora

(expression)  update statistics low for table categorias

(expression)  update statistics low for table fnosalta

(expression)  update statistics low for table tropa_pv

(expression)  update statistics low for table doc_pendientes

(expression)  update statistics low for table oficina

(expression)  update statistics low for table corr_seg

(expression)  update statistics low for table meomeop

(expression)  update statistics low for table tablas

(expression)  update statistics low for table chunk

(expression)  update statistics low for table cuentas

(expression)  update statistics low for table mfsue_et

(expression)  update statistics low for table mftror

(expression)  update statistics low for table aud_mftro

(expression)  update statistics low for table aud_mfsue_et

(expression)  update statistics low for table cmm_hospitalizados

(expression)  update statistics low for table cmm_rebajados

(expression)  update statistics low for table mnums

(expression)  update statistics low for table dfdes_tro

(expression)  update statistics low for table permper

(expression)  update statistics low for table permorga

(expression)  update statistics low for table process

(expression)  update statistics low for table ubicacion_cerrados

(expression)  update statistics low for table tr_armas

(expression)  update statistics low for table dcur

(expression)  update statistics low for table dfdes_btrab

(expression)  update statistics low for table ubicacion_docum

(expression)  update statistics low for table sistemas

(expression)  update statistics low for table hist_rep

(expression)  update statistics low for table agui

(expression)  update statistics low for table dfam

(expression)  update statistics low for table maestro

(expression)  update statistics low for table aud_ubica_cerra

(expression)  update statistics low for table dfdes_ipm

(expression)  update statistics low for table resutro

(expression)  update statistics low for table tsan

(expression)  update statistics low for table mdep

(expression)  update statistics low for table aud_permorga

(expression)  update statistics low for table documento

(expression)  update statistics low for table bono14

(expression)  update statistics low for table aud_doc_pendientes

(expression)  update statistics low for table aud_mftror

(expression)  update statistics low for table aud_meomeop

(expression)  update statistics low for table aud_tropabajas

(expression)  update statistics low for table marginado

(expression)  update statistics low for table doc_cerrados

(expression)  update statistics low for table aud_doc_cerrados

(expression)  update statistics low for table aud_dcur

(expression)  update statistics low for table mlins

(expression)  update statistics low for table situaciones

(expression)  update statistics low for table tempdpue

(expression)  update statistics low for table usuariosnt

(expression)  update statistics low for table aud_dpue

(expression)  update statistics low for table permorden

(expression)  update statistics low for table cla_cond

(expression)  update statistics low for table lsm_marca

(expression)  update statistics low for table lsm_equipo

(expression)  update statistics low for table menu_det

(expression)  update statistics low for table orden

(expression)  update statistics low for table orden_h

(expression)  update statistics low for table sitrasla

(expression)  update statistics low for table hfdes1

(expression)  update statistics low for table hfasigc

(expression)  update statistics low for table dlicen

(expression)  update statistics low for table tusuar

(expression)  update statistics low for table indice_dau

(expression)  update statistics low for table eva_detalle

(expression)  update statistics low for table accesos

(expression)  update statistics low for table rh_evaluacion

(expression)  update statistics low for table rh_aspecto

(expression)  update statistics low for table rh_tipo_aspecto

(expression)  update statistics low for table rh_categoria

(expression)  update statistics low for table rh_det_evaluacion

(expression)  update statistics low for table aud_asamblea

(expression)  update statistics low for table aud_asig_cat

(expression)  update statistics low for table aud_asig_plaza

(expression)  update statistics low for table aud_categorias

(expression)  update statistics low for table aud_cmm_rebajados

(expression)  update statistics low for table aud_depmun

(expression)  update statistics low for table aud_des_no_efec

(expression)  update statistics low for table aud_descripciones

(expression)  update statistics low for table aud_eva_detalle

(expression)  update statistics low for table aud_disr

(expression)  update statistics low for table insp_tipos

(expression)  update statistics low for table insp_situacion

(expression)  update statistics low for table insp_nueva

(expression)  update statistics low for table insp_ianota

(expression)  update statistics low for table insp_estado

(expression)  update statistics low for table insp_anotaciones

(expression)  update statistics low for table aud_insp_nueva

(expression)  update statistics low for table aud_insp_situacion

(expression)  update statistics low for table aud_insp_estado

(expression)  update statistics low for table aud_insp_tipos

(expression)  update statistics low for table aud_insp_anotaciones

(expression)  update statistics low for table aud_insp_ianota

(expression)  update statistics low for table cc_tip_requerimiento

(expression)  update statistics low for table cc_divisiones

(expression)  update statistics low for table cc_situaciones

(expression)  update statistics low for table cc_problemas

(expression)  update statistics low for table aud_cc_divisiones

(expression)  update statistics low for table aud_cc_problemas

(expression)  update statistics low for table aud_cc_situaciones

(expression)  update statistics low for table aud_cc_tip_requerimiento

(expression)  update statistics low for table aud_dfdes_inv

(expression)  update statistics low for table aud_dfdes_invt

(expression)  update statistics low for table aud_dfdes_ipm

(expression)  update statistics low for table insp_inmuebles

(expression)  update statistics low for table aud_accesos

(expression)  update statistics low for table aud_chunk

(expression)  update statistics low for table aud_cla_cond

(expression)  update statistics low for table aud_empresas

(expression)  update statistics low for table aud_fbitacora

(expression)  update statistics low for table aud_fmasi

(expression)  update statistics low for table aud_fmdes

(expression)  update statistics low for table aud_fnosalta

(expression)  update statistics low for table aud_fuerza

(expression)  update statistics low for table aud_hdareal

(expression)  update statistics low for table aud_hist_rep

(expression)  update statistics low for table aud_indice_dau

(expression)  update statistics low for table insp_observaciones

(expression)  update statistics low for table aud_insp_observaciones

(expression)  update statistics low for table aud_lsm_equipo

(expression)  update statistics low for table aud_lsm_marca

(expression)  update statistics low for table aud_maestro

(expression)  update statistics low for table aud_mcols

(expression)  update statistics low for table aud_mlins

(expression)  update statistics low for table aud_mnums

(expression)  update statistics low for table aud_mreps

(expression)  update statistics low for table aud_rh_aspecto

(expression)  update statistics low for table aud_rh_categoria

(expression)  update statistics low for table aud_rh_det_evaluacion

(expression)  update statistics low for table aud_rh_evaluacion

(expression)  update statistics low for table aud_rh_tipo_aspecto

(expression)  update statistics low for table aud_noestan

(expression)  update statistics low for table aud_nopagados

(expression)  update statistics low for table aud_orden_h

(expression)  update statistics low for table aud_pdinero

(expression)  update statistics low for table aud_permorden

(expression)  update statistics low for table aud_process

(expression)  update statistics low for table aud_retencion

(expression)  update statistics low for table aud_sinefecto

(expression)  update statistics low for table aud_sistemas

(expression)  update statistics low for table aud_sitrasla

(expression)  update statistics low for table aud_t_org

(expression)  update statistics low for table aud_tablas

(expression)  update statistics low for table aud_tconec

(expression)  update statistics low for table aud_tauth

(expression)  update statistics low for table aud_telefonos

(expression)  update statistics low for table aud_tempdpue

(expression)  update statistics low for table aud_tr_armas

(expression)  update statistics low for table aud_tusuar

(expression)  update statistics low for table aud_usuarios

(expression)  update statistics low for table aud_usuarios_sistema

(expression)  update statistics low for table aud_usuariosnt

(expression)  update statistics low for table aud_usumenu

(expression)  update statistics low for table cc_dticket

(expression)  update statistics low for table cc_mticket

(expression)  update statistics low for table aud_cc_mticket

(expression)  update statistics low for table aud_cc_dticket

(expression)  update statistics low for table aud_insp_inmuebles

(expression)  update statistics low for table c_proposito

(expression)  update statistics low for table aud_c_proposito

(expression)  update statistics low for table c_empresas

(expression)  update statistics low for table aud_c_empresas

(expression)  update statistics low for table aud_c_oficinas

(expression)  update statistics low for table aud_c_tipo_docum

(expression)  update statistics low for table aud_c_corr_seg

(expression)  update statistics low for table aud_pcdtablr

(expression)  update statistics low for table aud_armas

(expression)  update statistics low for table aud_asignaciones

(expression)  update statistics low for table aud_banderas

(expression)  update statistics low for table tropa_cuenta

(expression)  update statistics low for table aud_cursos

(expression)  update statistics low for table aud_dep_mun

(expression)  update statistics low for table aud_descuentos

(expression)  update statistics low for table aud_dlicen

(expression)  update statistics low for table aud_escuelas

(expression)  update statistics low for table aud_evaluacion

(expression)  update statistics low for table aud_grados

(expression)  update statistics low for table aud_marginado

(expression)  update statistics low for table aud_mdep

(expression)  update statistics low for table aud_menu_det

(expression)  update statistics low for table aud_menu_master

(expression)  update statistics low for table aud_menus

(expression)  update statistics low for table aud_meom

(expression)  update statistics low for table aud_meop

(expression)  update statistics low for table aud_mfdep

(expression)  update statistics low for table aud_mfsub

(expression)  update statistics low for table aud_mfsue_e

(expression)  update statistics low for table aud_mfsue_o

(expression)  update statistics low for table aud_oficina

(expression)  update statistics low for table aud_paises

(expression)  update statistics low for table aud_parentescos

(expression)  update statistics low for table aud_pbienal

(expression)  update statistics low for table aud_permisos

(expression)  update statistics low for table aud_permper

(expression)  update statistics low for table aud_permtropa

(expression)  update statistics low for table aud_situaciones

(expression)  update statistics low for table aud_tipo_docum

(expression)  update statistics low for table aud_tropa_pv

(expression)  update statistics low for table aud_tropa_sp

(expression)  update statistics low for table aud_tsan

(expression)  update statistics low for table aud_jefes

(expression)  update statistics low for table aud_corr_seg

(expression)  update statistics low for table aud_sand

(expression)  update statistics low for table c_oficinas

(expression)  update statistics low for table c_tipo_docum

(expression)  update statistics low for table r_papel

(expression)  update statistics low for table r_programas

(expression)  update statistics low for table aud_r_programas

(expression)  update statistics low for table aud_r_papel

(expression)  update statistics low for table aud_r_det_requerimientos

(expression)  update statistics low for table economato

(expression)  update statistics low for table aud_f_hreal

(expression)  update statistics low for table r_requerimientos

(expression)  update statistics low for table aud_r_requerimientos

(expression)  update statistics low for table r_det_req

(expression)  update statistics low for table aud_vocales

(expression)  update statistics low for table vocales

(expression)  update statistics low for table usuapli

(expression)  update statistics low for table c_control

(expression)  update statistics low for table aud_usu_opera

(expression)  update statistics low for table aud_opera_menu

(expression)  update statistics low for table opera_menu

(expression)  update statistics low for table usu_opera

(expression)  update statistics low for table co_mper

(expression)  update statistics low for table aud_co_mper

(expression)  update statistics low for table aud_sysmenus

(expression)  update statistics low for table esip_unidades_ejecutoras

(expression)  update statistics low for table diagnosticos

(expression)  update statistics low for table aud_diagnosticos

(expression)  update statistics low for table aud_ingreso

(expression)  update statistics low for table aud_busqueda

(expression)  update statistics low for table evaluaciones_ant

(expression)  update statistics low for table aud_documento

(expression)  update statistics low for table aud_ubica_docum

(expression)  update statistics low for table aud_msan

(expression)  update statistics low for table resofi

(expression)  update statistics low for table descripciones

(expression)  update statistics low for table f_hfag

(expression)  update statistics low for table aud_f_hfag

(expression)  update statistics low for table hfasig

(expression)  update statistics low for table hfdes

(expression)  update statistics low for table aud_f_bac

(expression)  update statistics low for table aud_f_amt

(expression)  update statistics low for table aud_icombus

(expression)  update statistics low for table icombus

(expression)  update statistics low for table icorep

(expression)  update statistics low for table icobsrep

(expression)  update statistics low for table aud_icorep

(expression)  update statistics low for table aud_icodetrep

(expression)  update statistics low for table aud_icobsrep

(expression)  update statistics low for table icodetrep

(expression)  update statistics low for table chn

(expression)  update statistics low for table aud_chn

(expression)  update statistics low for table fceom

(expression)  update statistics low for table aud_fceom

(expression)  update statistics low for table asigna

(expression)  update statistics low for table ftempo

(expression)  update statistics low for table aud_ftempo

(expression)  update statistics low for table aud_f_mulfar

(expression)  update statistics low for table f_mulfar

(expression)  update statistics low for table aud_yakis

(expression)  update statistics low for table aud_evaluaciones_ant

(expression)  update statistics low for table pacceso

(expression)  update statistics low for table pdocumento

(expression)  update statistics low for table pestado

(expression)  update statistics low for table pnegociado

(expression)  update statistics low for table ptipo

(expression)  update statistics low for table aud_pdocumento

(expression)  update statistics low for table aud_ptipo

(expression)  update statistics low for table aud_pestado

(expression)  update statistics low for table aud_pnegociado

(expression)  update statistics low for table aud_pacceso

(expression)  update statistics low for table aud_ptiempos

(expression)  update statistics low for table ptiempos

(expression)  update statistics low for table tconec

(expression)  update statistics low for table fincas

(expression)  update statistics low for table aud_fincas

(expression)  update statistics low for table asig_cat

(expression)  update statistics low for table c_corr_seg

(expression)  update statistics low for table c_documento

(expression)  update statistics low for table c_ubicacion_docum

(expression)  update statistics low for table dpue

(expression)  update statistics low for table mtit

(expression)  update statistics low for table sand

(expression)  update statistics low for table telefonos

(expression)  update statistics low for table t_org

(expression)  update statistics low for table ret_of_carre_res

(expression)  update statistics low for table ret_tropa

(expression)  update statistics low for table ret_desc_im

(expression)  update statistics low for table ret_desc_hr

(expression)  update statistics low for table ret_desc_ipm_asim

(expression)  update statistics low for table ret_desc_ipm_esptas

(expression)  update statistics low for table ret_desc_ipm_of

(expression)  update statistics low for table ret_desc_ipm_sgtos_may

(expression)  update statistics low for table ret_of_asim

(expression)  update statistics low for table ret_esptas

(expression)  update statistics low for table ret_sgtos_may

(expression)  update statistics low for table aud_ret_desc_hr

(expression)  update statistics low for table aud_ret_desc_im

(expression)  update statistics low for table aud_ret_desc_ipm_esptas

(expression)  update statistics low for table aud_ret_desc_ipm_of

(expression)  update statistics low for table aud_ret_desc_ipm_sgtos_may

(expression)  update statistics low for table aud_ret_of_asim

(expression)  update statistics low for table aud_ret_of_carre_res

(expression)  update statistics low for table aud_ret_sgtos_may

(expression)  update statistics low for table aud_ret_desc_ipm_asim

(expression)  update statistics low for table retiro

(expression)  update statistics low for table aud_asigna

(expression)  update statistics low for table aud_c_control

(expression)  update statistics low for table aud_usuapli

(expression)  update statistics low for table aud_cmm_hospitalizados

(expression)  update statistics low for table aud_retiro

(expression)  update statistics low for table f_resumen

(expression)  update statistics low for table f_datosfza

(expression)  update statistics low for table aplicaciones

(expression)  update statistics low for table divisiones

(expression)  update statistics low for table negociados

(expression)  update statistics low for table u_comisiones

(expression)  update statistics low for table aud_aplicaciones

(expression)  update statistics low for table aud_divisiones

(expression)  update statistics low for table aud_negociados

(expression)  update statistics low for table aud_u_comisiones

(expression)  update statistics low for table f_ipm_cart

(expression)  update statistics low for table agtsa

(expression)  update statistics low for table asamblea

(expression)  update statistics low for table banejer_car

(expression)  update statistics low for table dfdes_gra

(expression)  update statistics low for table dfdes_grat

(expression)  update statistics low for table dfdes_inv

(expression)  update statistics low for table dfdes_invt

(expression)  update statistics low for table f_amt

(expression)  update statistics low for table f_bac

(expression)  update statistics low for table f_combust

(expression)  update statistics low for table f_hreal

(expression)  update statistics low for table findustria

(expression)  update statistics low for table f_asgral

(expression)  update statistics low for table mper

(expression)  update statistics low for table aud_permiso

(expression)  update statistics low for table permiso

(expression)  update statistics low for table fn_motivos

(expression)  update statistics low for table aud_fn_motivos

(expression)  update statistics low for table aud_f_cmm

(expression)  update statistics low for table f_cmm

(expression)  update statistics low for table hftro_des

(expression)  update statistics low for table ft_asigna

(expression)  update statistics low for table aud_ft_asigna

(expression)  update statistics low for table busqueda

(expression)  update statistics low for table ingreso

(expression)  update statistics low for table fcatnop

(expression)  update statistics low for table aud_fcatnop

(expression)  update statistics low for table cna

(expression)  update statistics low for table larm_lot

(expression)  update statistics low for table aud_coc_planificar

(expression)  update statistics low for table religiones

(expression)  update statistics low for table rel_detalle

(expression)  update statistics low for table aud_religiones

(expression)  update statistics low for table aud_rel_detalle

(expression)  update statistics low for table cnc

(expression)  update statistics low for table radius1

(expression)  update statistics low for table aud_oestoe

(expression)  update statistics low for table oestoe

(expression)  update statistics low for table aud_mtit

(expression)  update statistics low for table aud_resofi

(expression)  update statistics low for table aud_f_resumen

(expression)  update statistics low for table aud_ret_esptas

(expression)  update statistics low for table aud_findustria

(expression)  update statistics low for table aud_banejer_acc

(expression)  update statistics low for table xsql_languages

(expression)  update statistics low for table xserver_info

(expression)  update statistics low for table dfdes_frasa

(expression)  update statistics low for table aud_dfdes_frasa

(expression)  update statistics low for table msan

(expression)  update statistics low for table aud_resutro

(expression)  update statistics low for table aud_hftro_des

(expression)  update statistics low for table aud_partidas

(expression)  update statistics low for table aud_orden

(expression)  update statistics low for table aud_ret_tropa

(expression)  update statistics low for table aud_f_datosfza

(expression)  update statistics low for table aud_f_asgral

(expression)  update statistics low for table aud_f_combust

(expression)  update statistics low for table f_seguros_gt

(expression)  update statistics low for table aud_hftro

(expression)  update statistics low for table aud_pafe_oficiales

(expression)  update statistics low for table pafe_oficiales

(expression)  update statistics low for table dfasig

(expression)  update statistics low for table c_tareas

(expression)  update statistics low for table aud_c_tareas

(expression)  update statistics low for table recepcion

(expression)  update statistics low for table marca

(expression)  update statistics low for table equipos

(expression)  update statistics low for table aud_equipos

(expression)  update statistics low for table aud_marca

(expression)  update statistics low for table aud_recepcion

(expression)  update statistics low for table eacciones

(expression)  update statistics low for table eusuarios

(expression)  update statistics low for table aud_det_acciones

(expression)  update statistics low for table aud_eacciones

(expression)  update statistics low for table aud_eusuarios

(expression)  update statistics low for table det_acciones

(expression)  update statistics low for table paf_actas

(expression)  update statistics low for table paf_calendario

(expression)  update statistics low for table paf_periodos

(expression)  update statistics low for table paf_grafica

(expression)  update statistics low for table aud_paf_actas

(expression)  update statistics low for table aud_paf_calendario

(expression)  update statistics low for table aud_paf_detalle

(expression)  update statistics low for table aud_paf_periodos

(expression)  update statistics low for table aud_paf_programador

(expression)  update statistics low for table paf_programador

(expression)  update statistics low for table paf_detalle

(expression)  update statistics low for table aud_tiempos

(expression)  update statistics low for table freforma

(expression)  update statistics low for table aud_freforma

(expression)  update statistics low for table licencias

(expression)  update statistics low for table aud_licencias

(expression)  update statistics low for table msanlla

(expression)  update statistics low for table sandlla

(expression)  update statistics low for table certificaciones

(expression)  update statistics low for table psan_orden

(expression)  update statistics low for table psan_estadistica

(expression)  update statistics low for table psan_registro

(expression)  update statistics low for table re22_cuentas

(expression)  update statistics low for table aud_psan_orden

(expression)  update statistics low for table aud_psan_estadistica

(expression)  update statistics low for table aud_psan_registro

(expression)  update statistics low for table aud_mper

(expression)  update statistics low for table aud_agtsa

(expression)  update statistics low for table aud_f_seguros_gt

(expression)  update statistics low for table aud_banejer_car

(expression)  update statistics low for table aud_economato

(expression)  update statistics low for table aud_ipm_fact

(expression)  update statistics low for table insti

(expression)  update statistics low for table aud_insti

(expression)  update statistics low for table tdfasig

(expression)  update statistics low for table tdfdes

(expression)  update statistics low for table tmper

(expression)  update statistics low for table boleta

(expression)  update statistics low for table cuentas15

(expression)  update statistics low for table despachos

(expression)  update statistics low for table det_isr

(expression)  update statistics low for table detalle

(expression)  update statistics low for table devoluciones

(expression)  update statistics low for table dper

(expression)  update statistics low for table fmdescue

(expression)  update statistics low for table fthreal400

(expression)  update statistics low for table hisfin

(expression)  update statistics low for table ipm_cart

(expression)  update statistics low for table ipm_manto

(expression)  update statistics low for table seguridad

(expression)  update statistics low for table pickers

(expression)  update statistics low for table n_asig_plaza

(expression)  update statistics low for table n_control_plaza

(expression)  update statistics low for table n_morg

(expression)  update statistics low for table n_mper

(expression)  update statistics low for table n_mtit

(expression)  update statistics low for table n_orgfun

(expression)  update statistics low for table n_plaza

(expression)  update statistics low for table aud_conyugues

(expression)  update statistics low for table conyugues

(expression)  update statistics low for table lves_tallas

(expression)  update statistics low for table aud_lves_tallas

(expression)  update statistics low for table morg_temp

(expression)  update statistics low for table org_meom_detalle

(expression)  update statistics low for table org_meom_funciones

(expression)  update statistics low for table org_meom_req

(expression)  update statistics low for table org_seguridad

(expression)  update statistics low for table aud_org_meom_detalle

(expression)  update statistics low for table aud_org_meom_funciones

(expression)  update statistics low for table aud_org_meom_req

(expression)  update statistics low for table aud_oede_entrena

(expression)  update statistics low for table aud_oema_entrena

(expression)  update statistics low for table aud_oetd_entrena

(expression)  update statistics low for table oeac_entrena

(expression)  update statistics low for table aud_oeac_entrena

(expression)  update statistics low for table aud_oeta_entrena

(expression)  update statistics low for table oedr_entrena

(expression)  update statistics low for table aud_oedr_entrena

(expression)  update statistics low for table aud_oerq_entrena

(expression)  update statistics low for table aud_oetr_entrena

(expression)  update statistics low for table morg

(expression)  update statistics low for table oetd_entrena

(expression)  update statistics low for table oeta_entrena

(expression)  update statistics low for table oerq_entrena

(expression)  update statistics low for table oetr_entrena

(expression)  update statistics low for table oema_entrena

(expression)  update statistics low for table oede_entrena

(expression)  update statistics low for table pcon_maestra

(expression)  update statistics low for table pcon_detalle

(expression)  update statistics low for table pcon_personalidad

(expression)  update statistics low for table pcond_especial

(expression)  update statistics low for table aud_fdes_empresas

(expression)  update statistics low for table hftro

(expression)  update statistics low for table fdes_empresas

(expression)  update statistics low for table peva_concept

(expression)  update statistics low for table peva_proyeccion

(expression)  update statistics low for table peva_control_dep

(expression)  update statistics low for table peva_periodos_ant

(expression)  update statistics low for table aud_peva_concept

(expression)  update statistics low for table aud_peva_proyeccion

(expression)  update statistics low for table aud_peva_control_dep

(expression)  update statistics low for table aud_peva_periodos_ant

(expression)  update statistics low for table aud_opaf_usuario

(expression)  update statistics low for table sop_equipos

(expression)  update statistics low for table sop_marcas

(expression)  update statistics low for table sop_soporte

(expression)  update statistics low for table aud_sop_equipos

(expression)  update statistics low for table aud_sop_marcas

(expression)  update statistics low for table aud_sop_soporte

(expression)  update statistics low for table opaf_dominadas

(expression)  update statistics low for table opaf_abdominales

(expression)  update statistics low for table aud_opaf_dominadas

(expression)  update statistics low for table aud_opaf_abdominales

(expression)  update statistics low for table opaf_alterno

(expression)  update statistics low for table aud_opaf_alterno

(expression)  update statistics low for table opaf_carrera

(expression)  update statistics low for table aud_opaf_carrera

(expression)  update statistics low for table eva_especialistas

(expression)  update statistics low for table eva_tipo

(expression)  update statistics low for table aud_eva_tipo

(expression)  update statistics low for table aud_eva_especialistas

(expression)  update statistics low for table permiso_autocom

(expression)  update statistics low for table aud_permiso_autocom

(expression)  update statistics low for table evaluaciones

(expression)  update statistics low for table aud_evaluaciones

(expression)  update statistics low for table jefes_ant

(expression)  update statistics low for table aud_morg

(expression)  update statistics low for table coc_dman

(expression)  update statistics low for table aud_dfdes_grat

(expression)  update statistics low for table evaluacion_ant

(expression)  update statistics low for table ef_fuerza

(expression)  update statistics low for table ef_destinos_ant

(expression)  update statistics low for table ef_usuarios

(expression)  update statistics low for table diagnostico

(expression)  update statistics low for table evaluacion

(expression)  update statistics low for table aud_ef_fuerza

(expression)  update statistics low for table aud_ef_destinos_ant

(expression)  update statistics low for table aud_ef_usuarios

(expression)  update statistics low for table ei_asignaciones

(expression)  update statistics low for table aud_ei_asignaciones

(expression)  update statistics low for table ei_cursos_asig

(expression)  update statistics low for table aud_ei_cursos_asig

(expression)  update statistics low for table ei_cursos_reali

(expression)  update statistics low for table aud_ei_cursos_reali

(expression)  update statistics low for table ei_mper_extranjero

(expression)  update statistics low for table aud_ei_mper_extranjero

(expression)  update statistics low for table ei_materias

(expression)  update statistics low for table aud_ei_materias

(expression)  update statistics low for table ei_notas

(expression)  update statistics low for table aud_ei_notas

(expression)  update statistics low for table ei_tipo_curso

(expression)  update statistics low for table aud_ei_tipo_curso

(expression)  update statistics low for table ef_detalle

(expression)  update statistics low for table aud_ef_detalle

(expression)  update statistics low for table aud_radius1

(expression)  update statistics low for table pass

(expression)  update statistics low for table ef_destinos

(expression)  update statistics low for table aud_ef_destinos

(expression)  update statistics low for table menuautocom

(expression)  update statistics low for table grupo_menuautocom

(expression)  update statistics low for table niveles_autocom

(expression)  update statistics low for table aud_opaf_notas

(expression)  update statistics low for table opaf_notas

(expression)  update statistics low for table opaf_usuario

(expression)  update statistics low for table aud_larm_det

(expression)  update statistics low for table aud_larm_lot

(expression)  update statistics low for table aud_larm_sit

(expression)  update statistics low for table aud_larm_tip

(expression)  update statistics low for table aud_lmarmas

(expression)  update statistics low for table aud_lhrep

(expression)  update statistics low for table larm_sit

(expression)  update statistics low for table larm_tip

(expression)  update statistics low for table aud_coc_dman

(expression)  update statistics low for table larm_loc

(expression)  update statistics low for table lmarmas

(expression)  update statistics low for table larm_det

(expression)  update statistics low for table lhrep

(expression)  update statistics low for table larm_detalle

(expression)  update statistics low for table aud_larm_detalle

(expression)  update statistics low for table aud_hfasig

(expression)  update statistics low for table aud_c_documento

(expression)  update statistics low for table aud_hfasigc

(expression)  update statistics low for table aud_dfdes_btrab

(expression)  update statistics low for table aud_hfdes1

(expression)  update statistics low for table aud_dfasig

(expression)  update statistics low for table aud_hfdes

(expression)  update statistics low for table aud_c_ubicacion_docum

(expression)  update statistics low for table aud_f_ipm_cart

(expression)  update statistics low for table aud_dfdes_tro

(expression)  update statistics low for table aud_cuentas

(expression)  update statistics low for table aud_bono14

(expression)  update statistics low for table aud_dfdes_gra

(expression)  update statistics low for table aud_agui

(expression)  update statistics low for table peva_periodos

(expression)  update statistics low for table peva_admin

(expression)  update statistics low for table peva_aut_em

(expression)  update statistics low for table peva_conceptos

(expression)  update statistics low for table peva_evaluacion

(expression)  update statistics low for table peva_notas

(expression)  update statistics low for table peva_funciones

(expression)  update statistics low for table peva_autentica

(expression)  update statistics low for table aud_peva_admin

(expression)  update statistics low for table aud_peva_aut_em

(expression)  update statistics low for table aud_peva_conceptos

(expression)  update statistics low for table aud_peva_evaluacion

(expression)  update statistics low for table aud_peva_notas

(expression)  update statistics low for table aud_peva_funciones

(expression)  update statistics low for table aud_peva_autentica

(expression)  update statistics low for table aud_peva_periodos

(expression)  update statistics low for table larm_tip_sol

(expression)  update statistics low for table aud_larm_tip_sol

(expression)  update statistics low for table aud_larm_mov

(expression)  update statistics low for table aud_larm_temp

(expression)  update statistics low for table aud_ceom_funcion

(expression)  update statistics low for table ceom_funcion

(expression)  update statistics low for table aud_peva_objetivos

(expression)  update statistics low for table peva_objetivos

(expression)  update statistics low for table mdep_tipo

(expression)  update statistics low for table lmarmas_ag

(expression)  update statistics low for table lade_conocimiento

(expression)  update statistics low for table lali_conoc

(expression)  update statistics low for table usuarios_ige

(expression)  update statistics low for table lama_conoc

(expression)  update statistics low for table lmarmas_ag1

(expression)  update statistics low for table mdep_conocimiento

(expression)  update statistics low for table lama_almacen

(expression)  update statistics low for table larm_buscerradas

(expression)  update statistics low for table aud_larm_buscerradas

(expression)  update statistics low for table uniformes

(expression)  update statistics low for table aud_uniformes

(expression)  update statistics low for table aud_detalle_solicitud

(expression)  update statistics low for table aud_solicitud_uniformes

(expression)  update statistics low for table detalle_solicitud

(expression)  update statistics low for table larm_mov

(expression)  update statistics low for table solicitud_uniformes

(expression)  update statistics low for table dep_ubicacion

(expression)  update statistics low for table aud_dep_ubicacion

(expression)  update statistics low for table lmun_ent_sal_restore

(expression)  update statistics low for table aud_con_solicitud

(expression)  update statistics low for table det_consolicit

(expression)  update statistics low for table aud_det_consolicit

(expression)  update statistics low for table aud_tropa_cuenta

(expression)  update statistics low for table aud_dcon

(expression)  update statistics low for table dcon

(expression)  update statistics low for table eva_boleta

(expression)  update statistics low for table aud_eva_boleta

(expression)  update statistics low for table bol_det_meritos

(expression)  update statistics low for table aud_bol_det_meritos

(expression)  update statistics low for table bol_det_concep

(expression)  update statistics low for table aud_bol_det_concep

(expression)  update statistics low for table acc_motivadora

(expression)  update statistics low for table aud_acc_motivadora

(expression)  update statistics low for table test_table

(expression)  update statistics low for table aud_acc_correctiva

(expression)  update statistics low for table eva_meritos

(expression)  update statistics low for table aud_eva_meritos

(expression)  update statistics low for table eva_preguntas

(expression)  update statistics low for table aud_eva_preguntas

(expression)  update statistics low for table eva_datos

(expression)  update statistics low for table aud_eva_datos

(expression)  update statistics low for table eva_certifica

(expression)  update statistics low for table aud_eva_certifica

(expression)  update statistics low for table rnb_casco

(expression)  update statistics low for table aud_rnb_casco

(expression)  update statistics low for table rnb_motor

(expression)  update statistics low for table aud_rnb_motor

(expression)  update statistics low for table rnb_marca

(expression)  update statistics low for table aud_rnb_marca

(expression)  update statistics low for table rnb_modificacion

(expression)  update statistics low for table aud_rnb_modificacion

(expression)  update statistics low for table rnb_impuesto

(expression)  update statistics low for table aud_rnb_impuesto

(expression)  update statistics low for table rnb_tipo_emb

(expression)  update statistics low for table aud_rnb_tipo_emb

(expression)  update statistics low for table rnb_propietario

(expression)  update statistics low for table aud_rnb_propietario

(expression)  update statistics low for table rnb_color

(expression)  update statistics low for table aud_rnb_color

(expression)  update statistics low for table cumple_jefes

(expression)  update statistics low for table aud_rnb_embarcacion

(expression)  update statistics low for table rnb_licencia

(expression)  update statistics low for table aud_rnb_licencia

(expression)  update statistics low for table rnb_usuario

(expression)  update statistics low for table aud_rnb_usuario

(expression)  update statistics low for table rnb_inspeccion

(expression)  update statistics low for table aud_rnb_inspeccion

(expression)  update statistics low for table rnb_dependencia

(expression)  update statistics low for table aud_rnb_dependencia

(expression)  update statistics low for table rnb_matricula

(expression)  update statistics low for table aud_rnb_matricula

(expression)  update statistics low for table rnb_zarpe_inter

(expression)  update statistics low for table aud_rnb_zarpe_inter

(expression)  update statistics low for table rnb_zarpe

(expression)  update statistics low for table aud_rnb_zarpe

(expression)  update statistics low for table rnb_bitacora

(expression)  update statistics low for table aud_rnb_bitacora

(expression)  update statistics low for table rnb_atraque

(expression)  update statistics low for table aud_rnb_atraque

(expression)  update statistics low for table peva_detpersonal

(expression)  update statistics low for table aud_peva_detpersonal

(expression)  update statistics low for table aud_peva_boletasas

(expression)  update statistics low for table peva_certificaas

(expression)  update statistics low for table aud_peva_certificaas

(expression)  update statistics low for table peva_detbolconcep

(expression)  update statistics low for table aud_peva_detbolconcep

(expression)  update statistics low for table peva_boletasas

(expression)  update statistics low for table larm_inventario

(expression)  update statistics low for table aud_larm_inventario

(expression)  update statistics low for table pictures

(expression)  update statistics low for table his_morg

(expression)  update statistics low for table larm_hallazgo

(expression)  update statistics low for table aud_larm_hallazgo

(expression)  update statistics low for table per

(expression)  update statistics low for table lveh_neumaticos

(expression)  update statistics low for table aud_lveh_neumaticos

(expression)  update statistics low for table lveh_det_neumaticos

(expression)  update statistics low for table aud_lveh_det_neumaticos

(expression)  update statistics low for table lveh_det_plaza

(expression)  update statistics low for table aud_lveh_det_plaza

(expression)  update statistics low for table lveh_det_otros

(expression)  update statistics low for table aud_lveh_det_otros

(expression)  update statistics low for table lveh_estilo

(expression)  update statistics low for table aud_lveh_estilo

(expression)  update statistics low for table lveh_marcas

(expression)  update statistics low for table aud_lveh_marcas

(expression)  update statistics low for table lveh_tipo

(expression)  update statistics low for table aud_lveh_tipo

(expression)  update statistics low for table lvehiculos

(expression)  update statistics low for table aud_lvehiculos

(expression)  update statistics low for table lveh_det_transmision

(expression)  update statistics low for table lveh_det_motor

(expression)  update statistics low for table aud_lveh_det_motor

(expression)  update statistics low for table lveh_solicitud

(expression)  update statistics low for table aud_lveh_solicitud

(expression)  update statistics low for table toerenglon0

(expression)  update statistics low for table aud_lveh_combustible

(expression)  update statistics low for table lveh_aceite

(expression)  update statistics low for table aud_lveh_aceite

(expression)  update statistics low for table lveh_nuevo

(expression)  update statistics low for table lveh_det_documento

(expression)  update statistics low for table aud_lveh_det_documento

(expression)  update statistics low for table lveh_caracteristicas

(expression)  update statistics low for table aud_lveh_caracteristicas

(expression)  update statistics low for table lveh_asigna

(expression)  update statistics low for table aud_lveh_asigna

(expression)  update statistics low for table aud_lveh_nuevo

(expression)  update statistics low for table aud_larm_loc

(expression)  update statistics low for table conecta2

(expression)  update statistics low for table lveh_obser

(expression)  update statistics low for table aud_lveh_obser

(expression)  update statistics low for table lveh_his

(expression)  update statistics low for table aud_lveh_his

(expression)  update statistics low for table lveh_situacion

(expression)  update statistics low for table aud_lveh_situacion

(expression)  update statistics low for table lveh_color

(expression)  update statistics low for table aud_lveh_color

(expression)  update statistics low for table aud_lveh_det_transmision

(expression)  update statistics low for table aud_larm_solicitud

(expression)  update statistics low for table aud_larm_obser

(expression)  update statistics low for table larm_obser

(expression)  update statistics low for table tauth

(expression)  update statistics low for table ptel_personal

(expression)  update statistics low for table aud_ptel_personal

(expression)  update statistics low for table ptel_depen

(expression)  update statistics low for table aud_ptel_depen

(expression)  update statistics low for table ptel_centrix

(expression)  update statistics low for table aud_ptel_centrix

(expression)  update statistics low for table dfdes

(expression)  update statistics low for table aud_dfdes

(expression)  update statistics low for table psan_detalle

(expression)  update statistics low for table aud_psan_detalle

(expression)  update statistics low for table esp_clase_licencia

(expression)  update statistics low for table aud_esp_clase_licencia

(expression)  update statistics low for table esp_expertos

(expression)  update statistics low for table aud_esp_expertos

(expression)  update statistics low for table esp_permisos

(expression)  update statistics low for table aud_esp_permisos

(expression)  update statistics low for table esp_historial

(expression)  update statistics low for table aud_esp_historial

(expression)  update statistics low for table esp_det_permisos

(expression)  update statistics low for table aud_esp_det_permisos

(expression)  update statistics low for table esp_marcas

(expression)  update statistics low for table aud_esp_marcas

(expression)  update statistics low for table esp_grupo_producto

(expression)  update statistics low for table aud_esp_grupo_producto

(expression)  update statistics low for table esp_productos

(expression)  update statistics low for table aud_esp_productos

(expression)  update statistics low for table esp_unidad_medida

(expression)  update statistics low for table aud_esp_unidad_medida

(expression)  update statistics low for table esp_aduanas

(expression)  update statistics low for table aud_esp_aduanas

(expression)  update statistics low for table esp_inventario

(expression)  update statistics low for table aud_esp_inventario

(expression)  update statistics low for table esp_det_licencias

(expression)  update statistics low for table aud_esp_det_licencias

(expression)  update statistics low for table esp_aseguradoras

(expression)  update statistics low for table aud_esp_aseguradoras

(expression)  update statistics low for table esp_clase_permiso

(expression)  update statistics low for table aud_esp_clase_permiso

(expression)  update statistics low for table esp_licencias

(expression)  update statistics low for table aud_esp_licencias

(expression)  update statistics low for table esp_seguro

(expression)  update statistics low for table aud_esp_seguro

(expression)  update statistics low for table esp_empresas

(expression)  update statistics low for table aud_esp_empresas

(expression)  update statistics low for table esp_vehiculos

(expression)  update statistics low for table aud_esp_vehiculos

(expression)  update statistics low for table inv_proveedor

(expression)  update statistics low for table arco_not_creditos

(expression)  update statistics low for table usuarios

(expression)  update statistics low for table luni_solicitud

(expression)  update statistics low for table aud_luni_solicitud

(expression)  update statistics low for table luni_detallesoli

(expression)  update statistics low for table aud_luni_detallesoli

(expression)  update statistics low for table luni_detsol_log

(expression)  update statistics low for table aud_luni_detsol_log

(expression)  update statistics low for table luni_situacion

(expression)  update statistics low for table aud_luni_situacion

(expression)  update statistics low for table luni_documento

(expression)  update statistics low for table aud_luni_documento

(expression)  update statistics low for table luni_talla

(expression)  update statistics low for table aud_luni_talla

(expression)  update statistics low for table lmun_tipo1

(expression)  update statistics low for table lmun_calibre1

(expression)  update statistics low for table lmun_marca

(expression)  update statistics low for table lmun_color

(expression)  update statistics low for table lmun_modelo

(expression)  update statistics low for table lmun_fabrica

(expression)  update statistics low for table lmun_lote1

(expression)  update statistics low for table lmun_situacion

(expression)  update statistics low for table l_municion

(expression)  update statistics low for table lmun_uso1

(expression)  update statistics low for table lmun_carga

(expression)  update statistics low for table lmun_solicitud1

(expression)  update statistics low for table lmun_det_solicitud

(expression)  update statistics low for table lmun_det_solasigna

(expression)  update statistics low for table lmun_det_cambiosit

(expression)  update statistics low for table lmun_devolentre

(expression)  update statistics low for table lmun_mov_solicitud

(expression)  update statistics low for table lmun_correla

(expression)  update statistics low for table lmun_movimientos

(expression)  update statistics low for table lmun_asignacion

(expression)  update statistics low for table lmun_cambio_sit

(expression)  update statistics low for table lmun_trasint

(expression)  update statistics low for table seg_aspirantes

(expression)  update statistics low for table lmun_det_conocimiento

(expression)  update statistics low for table lmun_conoc_fab

(expression)  update statistics low for table lmun_det_conoc_fab

(expression)  update statistics low for table aud_lmun_tipo

(expression)  update statistics low for table aud_lmun_calibre

(expression)  update statistics low for table aud_lmun_marca

(expression)  update statistics low for table aud_lmun_color

(expression)  update statistics low for table aud_lmun_modelo

(expression)  update statistics low for table aud_lmun_fabrica

(expression)  update statistics low for table aud_lmun_lote

(expression)  update statistics low for table aud_lmun_situacion

(expression)  update statistics low for table aud_l_municion

(expression)  update statistics low for table aud_lmun_uso

(expression)  update statistics low for table aud_lmun_carga

(expression)  update statistics low for table aud_lmun_solicitud

(expression)  update statistics low for table aud_lmun_det_solicitud

(expression)  update statistics low for table aud_lmun_det_solasigna

(expression)  update statistics low for table aud_lmun_det_cambiosit

(expression)  update statistics low for table aud_lmun_devolentre

(expression)  update statistics low for table aud_lmun_mov_solicitud

(expression)  update statistics low for table aud_lmun_correla

(expression)  update statistics low for table aud_lmun_movimientos

(expression)  update statistics low for table aud_lmun_asignacion

(expression)  update statistics low for table aud_lmun_cambio_sit

(expression)  update statistics low for table aud_lmun_trasint

(expression)  update statistics low for table slc_dsal_fechas

(expression)  update statistics low for table aud_lmun_det_conocimiento

(expression)  update statistics low for table aud_lmun_conoc_fab

(expression)  update statistics low for table aud_lmun_det_conoc_fab

(expression)  update statistics low for table pcapa_det_solicitud

(expression)  update statistics low for table aud_pcapa_det_solicitud

(expression)  update statistics low for table pocur_solicitud

(expression)  update statistics low for table aud_pocur_solicitud

(expression)  update statistics low for table pdcapacitacion

(expression)  update statistics low for table aud_pdcapacitacion

(expression)  update statistics low for table ocur_det_solicitud

(expression)  update statistics low for table aud_ocur_det_solicitud

(expression)  update statistics low for table usuarios_sistema

(expression)  update statistics low for table luni_asignacion

(expression)  update statistics low for table aud_luni_asignacion

(expression)  update statistics low for table temp_fin_personal

(expression)  update statistics low for table arco_capacitaciones

(expression)  update statistics low for table aud_arco_capacitaciones

(expression)  update statistics low for table arco_cond

(expression)  update statistics low for table aud_arco_cond

(expression)  update statistics low for table arco_dcon

(expression)  update statistics low for table aud_arco_dcon

(expression)  update statistics low for table arco_dcur

(expression)  update statistics low for table aud_arco_dcur

(expression)  update statistics low for table arco_demeritos

(expression)  update statistics low for table aud_arco_demeritos

(expression)  update statistics low for table arco_erudiccion

(expression)  update statistics low for table aud_arco_erudiccion

(expression)  update statistics low for table arco_escalafon

(expression)  update statistics low for table aud_arco_escalafon

(expression)  update statistics low for table arco_evads

(expression)  update statistics low for table aud_arco_evads

(expression)  update statistics low for table arco_grados

(expression)  update statistics low for table aud_arco_grados

(expression)  update statistics low for table arco_notas

(expression)  update statistics low for table aud_arco_notas

(expression)  update statistics low for table arco_obligatorio

(expression)  update statistics low for table aud_arco_obligatorio

(expression)  update statistics low for table arco_pafes

(expression)  update statistics low for table aud_arco_pafes

(expression)  update statistics low for table arco_ponderacion

(expression)  update statistics low for table aud_arco_ponderacion

(expression)  update statistics low for table arco_sanciones

(expression)  update statistics low for table aud_arco_sanciones

(expression)  update statistics low for table arco_cursos

(expression)  update statistics low for table aud_arco_cursos

(expression)  update statistics low for table arco_jefes

(expression)  update statistics low for table aud_arco_jefes

(expression)  update statistics low for table aud_menuautocom

(expression)  update statistics low for table aud_niveles_autocom

(expression)  update statistics low for table aud_grupo_menuautocom

(expression)  update statistics low for table larm_solicitud

(expression)  update statistics low for table coc_coordenadas

(expression)  update statistics low for table aud_coc_coordenadas

(expression)  update statistics low for table coc_mision

(expression)  update statistics low for table aud_coc_mision

(expression)  update statistics low for table coc_personal

(expression)  update statistics low for table aud_coc_personal

(expression)  update statistics low for table coc_reporte

(expression)  update statistics low for table aud_coc_reporte

(expression)  update statistics low for table coc_tipo_veh

(expression)  update statistics low for table aud_coc_tipo_veh

(expression)  update statistics low for table coc_vehiculo_rep

(expression)  update statistics low for table aud_coc_vehiculo_rep

(expression)  update statistics low for table aud_fin_personal

(expression)  update statistics low for table fin_personal

(expression)  update statistics low for table lmun_conocimiento

(expression)  update statistics low for table arco_escalafon1

(expression)  update statistics low for table fin_contrato

(expression)  update statistics low for table aud_fin_contrato

(expression)  update statistics low for table fin_escuadrones

(expression)  update statistics low for table aud_fin_escuadrones

(expression)  update statistics low for table tiempos

(expression)  update statistics low for table bin_incidencia

(expression)  update statistics low for table bin_asignacion

(expression)  update statistics low for table arco_paridera

(expression)  update statistics low for table aud_bin_incidencia

(expression)  update statistics low for table arco_pcomando

(expression)  update statistics low for table cn

(expression)  update statistics low for table cnb

(expression)  update statistics low for table lmun_lote_asig

(expression)  update statistics low for table usu_autocom

(expression)  update statistics low for table aud_cn

(expression)  update statistics low for table aud_cnb

(expression)  update statistics low for table aud_cna

(expression)  update statistics low for table cns

(expression)  update statistics low for table aud_usu_sistemas

(expression)  update statistics low for table parentescos

(expression)  update statistics low for table prueba_dfam

(expression)  update statistics low for table aud_dfam

(expression)  update statistics low for table cor_corr_seg

(expression)  update statistics low for table aud_cor_corr_seg

(expression)  update statistics low for table lmun_asig_arm

(expression)  update statistics low for table mag_egresos

(expression)  update statistics low for table aud_mag_egresos

(expression)  update statistics low for table mag_inventario

(expression)  update statistics low for table aud_mag_inventario

(expression)  update statistics low for table mag_insumos

(expression)  update statistics low for table aud_mag_insumos

(expression)  update statistics low for table lmun_solicitud

(expression)  update statistics low for table lmun_lote

(expression)  update statistics low for table lmun_detalle_solicitud

(expression)  update statistics low for table arco_escalafonp

(expression)  update statistics low for table cor_tipo_docum

(expression)  update statistics low for table aud_cor_tipo_docum

(expression)  update statistics low for table cor_proposito

(expression)  update statistics low for table aud_cor_proposito

(expression)  update statistics low for table cor_ubicacion_docum

(expression)  update statistics low for table aud_cor_ubicacion_docum

(expression)  update statistics low for table cor_documento

(expression)  update statistics low for table aud_cor_documento

(expression)  update statistics low for table cor_empresas

(expression)  update statistics low for table aud_cor_empresas

(expression)  update statistics low for table cor_oficinas

(expression)  update statistics low for table aud_cor_oficinas

(expression)  update statistics low for table aud_cumple_jefes

(expression)  update statistics low for table lmun_tipo

(expression)  update statistics low for table lmun_calibre

(expression)  update statistics low for table lmun_uso

(expression)  update statistics low for table lmun_ent_sal

(expression)  update statistics low for table mper_otros

(expression)  update statistics low for table aud_lmarmas1

(expression)  update statistics low for table mag_det_ingreso

(expression)  update statistics low for table aud_mag_det_ingreso

(expression)  update statistics low for table mag_det_egreso

(expression)  update statistics low for table aud_mag_det_egreso

(expression)  update statistics low for table mag_ingresos

(expression)  update statistics low for table aud_mag_ingresos

(expression)  update statistics low for table dot_uniformes

(expression)  update statistics low for table aud_dot_uniformes

(expression)  update statistics low for table dot_solicitud

(expression)  update statistics low for table aud_inv_proveedor

(expression)  update statistics low for table aud_dot_solicitud

(expression)  update statistics low for table dot_detalle

(expression)  update statistics low for table aud_dot_detalle

(expression)  update statistics low for table inv_representante

(expression)  update statistics low for table inv_asig_repre_provee

(expression)  update statistics low for table inv_detalle

(expression)  update statistics low for table inv_formulario

(expression)  update statistics low for table inv_lote

(expression)  update statistics low for table inv_articulo

(expression)  update statistics low for table inv_grupo

(expression)  update statistics low for table inv_clase

(expression)  update statistics low for table aud_inv_clase

(expression)  update statistics low for table aud_inv_grupo

(expression)  update statistics low for table aud_inv_articulo

(expression)  update statistics low for table aud_inv_lote

(expression)  update statistics low for table aud_inv_formulario

(expression)  update statistics low for table aud_inv_detalle

(expression)  update statistics low for table aud_inv_asig_repre_provee

(expression)  update statistics low for table aud_inv_representante

(expression)  update statistics low for table dtx_accesorio

(expression)  update statistics low for table aud_dtx_accesorio

(expression)  update statistics low for table dtx_marca

(expression)  update statistics low for table dtx_articulo

(expression)  update statistics low for table aud_dtx_articulo

(expression)  update statistics low for table dtx_equipo

(expression)  update statistics low for table aud_dtx_equipo

(expression)  update statistics low for table aud_dtx_marca

(expression)  update statistics low for table aud_dtx_distribucion

(expression)  update statistics low for table dtx_distribucion

(expression)  update statistics low for table bin_situacion

(expression)  update statistics low for table aud_bin_situacion

(expression)  update statistics low for table bin_adquisicion

(expression)  update statistics low for table aud_bin_adquisicion

(expression)  update statistics low for table bin_tipos

(expression)  update statistics low for table aud_bin_tipos

(expression)  update statistics low for table bin_inmueble

(expression)  update statistics low for table aud_bin_inmueble

(expression)  update statistics low for table aud_bin_asignacion

(expression)  update statistics low for table aud_bin_accion

(expression)  update statistics low for table bin_accion

(expression)  update statistics low for table bin_utm

(expression)  update statistics low for table aud_bin_utm

(expression)  update statistics low for table bin_ubicacion

(expression)  update statistics low for table aud_bin_ubicacion

(expression)  update statistics low for table coc_dep_orden

(expression)  update statistics low for table coc_ope_planificada

(expression)  update statistics low for table ing_asi_maquinas

(expression)  update statistics low for table lemus

(expression)  update statistics low for table aud_ing_asi_maquinas

(expression)  update statistics low for table aud_psan_boleta

(expression)  update statistics low for table psan_boleta

(expression)  update statistics low for table ing_asi_subren

(expression)  update statistics low for table aud_ing_asi_subren

(expression)  update statistics low for table ing_proyecto

(expression)  update statistics low for table ing_maq_servicios

(expression)  update statistics low for table ing_asi_vehiculos

(expression)  update statistics low for table aud_ing_asi_vehiculos

(expression)  update statistics low for table ing_avances

(expression)  update statistics low for table aud_ing_avances

(expression)  update statistics low for table ing_hist_maquinas

(expression)  update statistics low for table aud_ing_hist_maquinas

(expression)  update statistics low for table ing_hist_vehiculos

(expression)  update statistics low for table aud_ing_hist_vehiculos

(expression)  update statistics low for table aud_ing_maq_servicios

(expression)  update statistics low for table ing_veh_servicios

(expression)  update statistics low for table aud_ing_maquinas

(expression)  update statistics low for table ing_vehiculos

(expression)  update statistics low for table ing_renglones

(expression)  update statistics low for table aud_ing_renglones

(expression)  update statistics low for table ing_subrenglones

(expression)  update statistics low for table aud_ing_subrenglones

(expression)  update statistics low for table aud_ing_tramos

(expression)  update statistics low for table aud_ing_veh_servicios

(expression)  update statistics low for table aud_ing_vehiculos

(expression)  update statistics low for table res_personal

(expression)  update statistics low for table aud_mper_otros

(expression)  update statistics low for table sancioness

(expression)  update statistics low for table estadisticaa

(expression)  update statistics low for table detallee

(expression)  update statistics low for table aud_ing_proyecto

(expression)  update statistics low for table historial_relestcivil

(expression)  update statistics low for table religion_personal

(expression)  update statistics low for table aud_historial_relestcivil

(expression)  update statistics low for table aud_religion_personal

(expression)  update statistics low for table eva_factores

(expression)  update statistics low for table aud_eva_factores

(expression)  update statistics low for table eva_linea

(expression)  update statistics low for table aud_eva_linea

(expression)  update statistics low for table eva_evaluacion

(expression)  update statistics low for table eva_notas

(expression)  update statistics low for table aud_eva_notas

(expression)  update statistics low for table aud_eva_evaluacion

(expression)  update statistics low for table ing_maquinas

(expression)  update statistics low for table aud_res_personal

(expression)  update statistics low for table respafe

(expression)  update statistics low for table aud_respafe

(expression)  update statistics low for table resascensos

(expression)  update statistics low for table aud_resascensos

(expression)  update statistics low for table resdfam

(expression)  update statistics low for table aud_resdfam

(expression)  update statistics low for table resorg

(expression)  update statistics low for table aud_resorg

(expression)  update statistics low for table dep_reservas

(expression)  update statistics low for table aud_dep_reservas

(expression)  update statistics low for table ing_tramos

(expression)  update statistics low for table con_ef_personal

(expression)  update statistics low for table bonoextra

(expression)  update statistics low for table llamada_atencion

(expression)  update statistics low for table aud_llamada_atencion

(expression)  update statistics low for table llamada_atencion_mod

(expression)  update statistics low for table aud_llamada_atencion_mod

(expression)  update statistics low for table sanciones

(expression)  update statistics low for table exp_uso

(expression)  update statistics low for table exp_tipo

(expression)  update statistics low for table exp_conocimiento

(expression)  update statistics low for table exp_solicitud

(expression)  update statistics low for table exp_solicitud_detalle

(expression)  update statistics low for table exp_proyecto

(expression)  update statistics low for table exp_ent_sal

(expression)  update statistics low for table control_toe

(expression)  update statistics low for table aud_control_toe

(expression)  update statistics low for table religion_segcontalu

(expression)  update statistics low for table aud_religion_segcontalu

(expression)  update statistics low for table sanciones_asc

(expression)  update statistics low for table con_permisos

(expression)  update statistics low for table con_solicitud

(expression)  update statistics low for table con_unidades

(expression)  update statistics low for table con_observaciones

(expression)  update statistics low for table con_mper_contratos

(expression)  update statistics low for table con_minuta

(expression)  update statistics low for table con_juridico

(expression)  update statistics low for table con_seguimiento

(expression)  update statistics low for table con_contrato

(expression)  update statistics low for table fmdep

(expression)  update statistics low for table lmun_conocimiento_restore

(expression)  update statistics low for table dfasig_tabla

(expression)  update statistics low for table con_area

(expression)  update statistics low for table aud_con_area

(expression)  update statistics low for table con_asignacion_plaza

(expression)  update statistics low for table aud_con_asignacion_plaza

(expression)  update statistics low for table con_boleta

(expression)  update statistics low for table aud_con_boleta

(expression)  update statistics low for table aud_con_mper_contratos

(expression)  update statistics low for table aud_con_juridico

(expression)  update statistics low for table aud_con_contrato

(expression)  update statistics low for table con_desc_area

(expression)  update statistics low for table aud_con_desc_area

(expression)  update statistics low for table con_desc_subareas

(expression)  update statistics low for table aud_con_desc_subareas

(expression)  update statistics low for table con_manual

(expression)  update statistics low for table aud_con_manual

(expression)  update statistics low for table aud_sanciones_asc

(expression)  update statistics low for table aud_con_minuta

(expression)  update statistics low for table aud_con_observaciones

(expression)  update statistics low for table aud_con_permisos

(expression)  update statistics low for table con_plaza

(expression)  update statistics low for table aud_con_plaza

(expression)  update statistics low for table aud_con_seguimiento

(expression)  update statistics low for table cont_solicitud

(expression)  update statistics low for table aud_cont_solicitud

(expression)  update statistics low for table con_subareas

(expression)  update statistics low for table aud_con_subareas

(expression)  update statistics low for table aud_con_unidades

(expression)  update statistics low for table aud_con_ef_personal

(expression)  update statistics low for table con_usuarios

(expression)  update statistics low for table aud_con_usuarios

(expression)  update statistics low for table cci_est_destino

(expression)  update statistics low for table aud_cci_est_destino

(expression)  update statistics low for table cci_est_fuerza

(expression)  update statistics low for table aud_cci_est_fuerza

(expression)  update statistics low for table cci_novedades

(expression)  update statistics low for table aud_cci_novedades

(expression)  update statistics low for table amp_registro_personal

(expression)  update statistics low for table vlh_t_cisterna

(expression)  update statistics low for table vlh_t_vehiculo

(expression)  update statistics low for table vlh_llantas

(expression)  update statistics low for table vlh_marcas

(expression)  update statistics low for table cont_curriculo

(expression)  update statistics low for table aud_cont_curriculo

(expression)  update statistics low for table aud_lmun_ent_sal

(expression)  update statistics low for table vlh_hidraulico_fag

(expression)  update statistics low for table aud_gpl_conductores

(expression)  update statistics low for table aud_gpl_transporte

(expression)  update statistics low for table vlh_cons_lubri_vehi

(expression)  update statistics low for table vlh_linea

(expression)  update statistics low for table vlh_aceite_fag

(expression)  update statistics low for table aud_vlh_aceite_fag

(expression)  update statistics low for table vlh_aeronave

(expression)  update statistics low for table aud_vlh_aeronave

(expression)  update statistics low for table vlh_apu

(expression)  update statistics low for table aud_vlh_apu

(expression)  update statistics low for table vlh_baterias

(expression)  update statistics low for table aud_vlh_baterias

(expression)  update statistics low for table aud_vlh_t_cisterna

(expression)  update statistics low for table aud_vlh_t_vehiculo

(expression)  update statistics low for table vlh_tipo_carroceria

(expression)  update statistics low for table aud_vlh_tipo_carroceria

(expression)  update statistics low for table vlh_tipo_combustible

(expression)  update statistics low for table aud_vlh_tipo_combustible

(expression)  update statistics low for table vlh_traccion_vehiculo

(expression)  update statistics low for table aud_vlh_traccion_vehiculo

(expression)  update statistics low for table vlh_transmision_vehiculo

(expression)  update statistics low for table aud_vlh_transmision_vehiculo

(expression)  update statistics low for table vlh_validaciones

(expression)  update statistics low for table aud_vlh_validaciones

(expression)  update statistics low for table vlh_permisos

(expression)  update statistics low for table aud_vlh_permisos

(expression)  update statistics low for table aud_vlh_hidraulico_fag

(expression)  update statistics low for table aud_vlh_marcas

(expression)  update statistics low for table aud_vlh_linea

(expression)  update statistics low for table aud_vlh_llantas

(expression)  update statistics low for table vlh_motor_fag

(expression)  update statistics low for table aud_vlh_motor_fag

(expression)  update statistics low for table vlh_neumaticos_fag

(expression)  update statistics low for table aud_vlh_neumaticos_fag

(expression)  update statistics low for table vlh_origen_vehiculo

(expression)  update statistics low for table aud_vlh_origen_vehiculo

(expression)  update statistics low for table vlh_estado_vehiculo

(expression)  update statistics low for table aud_vlh_estado_vehiculo

(expression)  update statistics low for table vlh_combustible_fag

(expression)  update statistics low for table aud_vlh_combustible_fag

(expression)  update statistics low for table vlh_cons_comb_vehi

(expression)  update statistics low for table aud_vlh_cons_comb_vehi

(expression)  update statistics low for table aud_vlh_cons_lubri_vehi

(expression)  update statistics low for table vlh_destino

(expression)  update statistics low for table aud_vlh_destino

(expression)  update statistics low for table vlh_carretones

(expression)  update statistics low for table vlh_equipo_terrestre_fag

(expression)  update statistics low for table vlh_embarcacion

(expression)  update statistics low for table vlh_remolques

(expression)  update statistics low for table aud_vlh_carretones

(expression)  update statistics low for table aud_vlh_equipo_terrestre_fag

(expression)  update statistics low for table aud_vlh_embarcacion

(expression)  update statistics low for table aud_vlh_remolques

(expression)  update statistics low for table vlh_caract_vehiculos

(expression)  update statistics low for table aud_vlh_caract_vehiculos

(expression)  update statistics low for table vlh_fag_caracteristicas

(expression)  update statistics low for table aud_vlh_fag_caracteristicas

(expression)  update statistics low for table gpl_t_comision

(expression)  update statistics low for table aud_gpl_t_comision

(expression)  update statistics low for table gpl_presidencial

(expression)  update statistics low for table aud_gpl_presidencial

(expression)  update statistics low for table cau_situaciones

(expression)  update statistics low for table aud_cau_situaciones

(expression)  update statistics low for table cau_permisos

(expression)  update statistics low for table aud_cau_permisos

(expression)  update statistics low for table pafe_alternos

(expression)  update statistics low for table rnb_embarcacion

(expression)  update statistics low for table personalc

(expression)  update statistics low for table coc_area_mision

(expression)  update statistics low for table vlh_tow

(expression)  update statistics low for table gpl_ubicacion

(expression)  update statistics low for table aud_gpl_ubicacion

(expression)  update statistics low for table gpl_lugar

(expression)  update statistics low for table aud_gpl_lugar

(expression)  update statistics low for table gpl_asig_lugar

(expression)  update statistics low for table aud_gpl_asig_lugar

(expression)  update statistics low for table gpl_transporte

(expression)  update statistics low for table dfdes_banrural

(expression)  update statistics low for table aud_dfdes_banrural

(expression)  update statistics low for table farma_dependencias_asignadas

(expression)  update statistics low for table lveh_combustible

(expression)  update statistics low for table seg_evaluacion

(expression)  update statistics low for table seg_examen

(expression)  update statistics low for table coc_metas

(expression)  update statistics low for table dfam_ipm

(expression)  update statistics low for table com_resumen

(expression)  update statistics low for table coc_proposito

(expression)  update statistics low for table coc_unidad_organica

(expression)  update statistics low for table coc_metodo_ejec

(expression)  update statistics low for table coc_operaciones

(expression)  update statistics low for table res_fam

(expression)  update statistics low for table coc_coordenadas2

(expression)  update statistics low for table coc_mensaje

(expression)  update statistics low for table coc_personal2

(expression)  update statistics low for table coc_vehiculo_rep2

(expression)  update statistics low for table ipm_dfam_temp

(expression)  update statistics low for table ef_fuerza_rsvp

(expression)  update statistics low for table ef_fuerza_ce

(expression)  update statistics low for table amp_ubicacion_personal

(expression)  update statistics low for table amp_asig_propietario

(expression)  update statistics low for table amp_lote

(expression)  update statistics low for table amp_manzana

(expression)  update statistics low for table amp_sector

(expression)  update statistics low for table opaf_abdominales1

(expression)  update statistics low for table opaf_carrera2

(expression)  update statistics low for table opaf_dominadas1

(expression)  update statistics low for table opaf_notas1

(expression)  update statistics low for table coc_control

(expression)  update statistics low for table gpl_actividad

(expression)  update statistics low for table gpl_ministerios

(expression)  update statistics low for table gpl_asig_mision

(expression)  update statistics low for table gpl_conductores

(expression)  update statistics low for table opaf_evento_per

(expression)  update statistics low for table res_mdep

(expression)  update statistics low for table res_reservas

(expression)  update statistics low for table coc_ordenes

(expression)  update statistics low for table aud_opaf_notas19

(expression)  update statistics low for table acc_correctiva

(expression)  update statistics low for table inmate

(expression)  update statistics low for table sig_agregados

(expression)  update statistics low for table sig_destinos

(expression)  update statistics low for table sig_unidades

(expression)  update statistics low for table sig_companias

(expression)  update statistics low for table sig_personal_contrato

(expression)  update statistics low for table sig_comisiones

(expression)  update statistics low for table sig_com_asig

(expression)  update statistics low for table sig_fuerza

(expression)  update statistics low for table sig_asig_companias

(expression)  update statistics low for table sig_marcas

(expression)  update statistics low for table sig_soporteotr

(expression)  update statistics low for table sig_soporteimp

(expression)  update statistics low for table sig_soportecpu

(expression)  update statistics low for table sig_soportemon

(expression)  update statistics low for table sig_novedades

(expression)  update statistics low for table sig_jefes_servicio

(expression)  update statistics low for table aud_sig_fuerza

(expression)  update statistics low for table aud_sig_agregados

(expression)  update statistics low for table aud_sig_destinos

(expression)  update statistics low for table aud_sig_unidades

(expression)  update statistics low for table aud_sig_companias

(expression)  update statistics low for table aud_sig_asig_companias

(expression)  update statistics low for table aud_sig_com_asig

(expression)  update statistics low for table aud_sig_comisiones

(expression)  update statistics low for table aud_sig_personal_contrato

(expression)  update statistics low for table aud_sig_marcas

(expression)  update statistics low for table aud_sig_novedades

(expression)  update statistics low for table aud_sig_jefes_servicio

(expression)  update statistics low for table aud_sig_soportecpu

(expression)  update statistics low for table aud_sig_soportemon

(expression)  update statistics low for table aud_sig_soporteimp

(expression)  update statistics low for table aud_sig_soporteotr

(expression)  update statistics low for table smg_tipos_mantenimiento

(expression)  update statistics low for table smg_motivos

(expression)  update statistics low for table smg_historial_mantenimiento

(expression)  update statistics low for table smg_historial_disparos

(expression)  update statistics low for table aud_smg_tipos_mantenimiento

(expression)  update statistics low for table aud_smg_motivos

(expression)  update statistics low for table aud_smg_historial_disparos

(expression)  update statistics low for table aud_smg_historial_mantenimiento

(expression)  update statistics low for table fp_fondo

(expression)  update statistics low for table fp_uso

(expression)  update statistics low for table fp_clasificacion

(expression)  update statistics low for table fp_estado

(expression)  update statistics low for table fp_respuesta

(expression)  update statistics low for table fp_documentos

(expression)  update statistics low for table fp_seguridad

(expression)  update statistics low for table lenguas

(expression)  update statistics low for table etnias

(expression)  update statistics low for table act_etnia

(expression)  update statistics low for table ep_mper

(expression)  update statistics low for table controlorgep

(expression)  update statistics low for table aud_fp_fondo

(expression)  update statistics low for table aud_fp_uso

(expression)  update statistics low for table aud_fp_estado

(expression)  update statistics low for table aud_fp_clasificacion

(expression)  update statistics low for table aud_fp_respuesta

(expression)  update statistics low for table fag_tip_aeronave

(expression)  update statistics low for table fag_aero_gt

(expression)  update statistics low for table fag_dep_estado

(expression)  update statistics low for table fag_hrs_historial_vuelo

(expression)  update statistics low for table fag_rep_mision_vuelo

(expression)  update statistics low for table fag_dest_vuelos

(expression)  update statistics low for table fag_rep_consumo_combustible

(expression)  update statistics low for table fag_vuelo_mision

(expression)  update statistics low for table aud_fp_documentos

(expression)  update statistics low for table aud_fp_seguridad

(expression)  update statistics low for table aud_fag_tip_aeronave

(expression)  update statistics low for table aud_fag_aero_gt

(expression)  update statistics low for table aud_fag_dep_estado

(expression)  update statistics low for table aud_fag_hrs_historial_vuelo

(expression)  update statistics low for table aud_fag_dest_vuelos

(expression)  update statistics low for table aud_fag_rep_consumo_combustible

(expression)  update statistics low for table aud_fag_rep_mision_vuelo

(expression)  update statistics low for table aud_fag_vuelo_mision

(expression)  update statistics low for table larm_temp

(expression)  update statistics low for table aud_re22_cuentas

(expression)  update statistics low for table psan_boleta_restore

(expression)  update statistics low for table sat_duca

(expression)  update statistics low for table aud_act_etnia

(expression)  update statistics low for table aud_etnias

(expression)  update statistics low for table far_contrato

(expression)  update statistics low for table far_proveedor

(expression)  update statistics low for table farma_presentaciones

(expression)  update statistics low for table aud_farma_farmacos

(expression)  update statistics low for table com_uniejec

(expression)  update statistics low for table aud_com_uniejec

(expression)  update statistics low for table aud_farma_dependencias_asignadas

(expression)  update statistics low for table aud_far_insumos_datos

(expression)  update statistics low for table farma_unidades_medida

(expression)  update statistics low for table aud_far_insumos_asignados

(expression)  update statistics low for table farma_tipo_medicamentos

(expression)  update statistics low for table farma_renglones_presupuestarios

(expression)  update statistics low for table farma_facturacion

(expression)  update statistics low for table aud_far_contrato

(expression)  update statistics low for table far_forma_pago

(expression)  update statistics low for table aud_far_forma_pago

(expression)  update statistics low for table rm_registros

(expression)  update statistics low for table aud_far_proveedor

(expression)  update statistics low for table aud_rm_registros

(expression)  update statistics low for table aud_farma_presentaciones

(expression)  update statistics low for table far_insumos_asignados

(expression)  update statistics low for table aud_farma_unidades_medida

(expression)  update statistics low for table aud_farma_tipo_medicamentos

(expression)  update statistics low for table aud_farma_renglones_presupuestari
              os

(expression)  update statistics low for table aud_far_insumos_suma

(expression)  update statistics low for table aud_farma_compra_asignada

(expression)  update statistics low for table aud_farma_orden_compra

(expression)  update statistics low for table aud_farma_presentacion_asignada

(expression)  update statistics low for table rm_beneficiarios

(expression)  update statistics low for table aud_farma_facturacion

(expression)  update statistics low for table farma_orden_compra

(expression)  update statistics low for table farma_compra_asignada

(expression)  update statistics low for table farma_presentacion_asignada

(expression)  update statistics low for table res_situacion

(expression)  update statistics low for table aud_res_situacion

(expression)  update statistics low for table res_tipo

(expression)  update statistics low for table aud_res_tipo

(expression)  update statistics low for table mprof

(expression)  update statistics low for table aud_mprof

(expression)  update statistics low for table res_asig_per

(expression)  update statistics low for table ddhh_gest

(expression)  update statistics low for table ddhh_gest_cont

(expression)  update statistics low for table aud_personalc

(expression)  update statistics low for table aud_res_fam

(expression)  update statistics low for table aud_res_reservas

(expression)  update statistics low for table aud_res_asig_per

(expression)  update statistics low for table aud_res_mdep

(expression)  update statistics low for table aud_ddhh_gest

(expression)  update statistics low for table aud_ddhh_gest_cont

(expression)  update statistics low for table prueba

(expression)  update statistics low for table re22_areas

(expression)  update statistics low for table re22_bancos

(expression)  update statistics low for table re22_bono_escolar

(expression)  update statistics low for table re22_bono_vacacional

(expression)  update statistics low for table re22_tipos_descuentos

(expression)  update statistics low for table re22_ocupaciones

(expression)  update statistics low for table re22_unidades_ejecutoras

(expression)  update statistics low for table re22_puestos

(expression)  update statistics low for table dot_articulos

(expression)  update statistics low for table aud_dot_articulos

(expression)  update statistics low for table re22_mper

(expression)  update statistics low for table re22_obras

(expression)  update statistics low for table dot_entrega

(expression)  update statistics low for table re22_subareas

(expression)  update statistics low for table aud_dot_tallas

(expression)  update statistics low for table re22_asignaciones

(expression)  update statistics low for table re22_control_pagos_isr

(expression)  update statistics low for table aud_sat_duca

(expression)  update statistics low for table aud_re22_descuentos

(expression)  update statistics low for table re22_fianzas

(expression)  update statistics low for table re22_obras_bono

(expression)  update statistics low for table re22_partidas

(expression)  update statistics low for table re22_personal_isr

(expression)  update statistics low for table re22_historial_pagos

(expression)  update statistics low for table re22_historial_situaciones

(expression)  update statistics low for table aud_re22_areas

(expression)  update statistics low for table aud_re22_bancos

(expression)  update statistics low for table aud_re22_bono_escolar

(expression)  update statistics low for table aud_re22_bono_vacacional

(expression)  update statistics low for table aud_re22_tipos_descuentos

(expression)  update statistics low for table aud_re22_ocupaciones

(expression)  update statistics low for table aud_re22_unidades_ejecutoras

(expression)  update statistics low for table aud_re22_puestos

(expression)  update statistics low for table aud_re22_mper

(expression)  update statistics low for table aud_re22_asignaciones

(expression)  update statistics low for table aud_re22_control_pagos_isr

(expression)  update statistics low for table dot_asignadas

(expression)  update statistics low for table re22_descuentos

(expression)  update statistics low for table aud_re22_fianzas

(expression)  update statistics low for table aud_re22_historial_pagos

(expression)  update statistics low for table aud_re22_historial_situaciones

(expression)  update statistics low for table aud_fin_subproducto

(expression)  update statistics low for table aud_re22_partidas

(expression)  update statistics low for table aud_re22_personal_isr

(expression)  update statistics low for table aud_re22_subareas

(expression)  update statistics low for table aud_re22_obras_bono

(expression)  update statistics low for table dot_tallas

(expression)  update statistics low for table dot_tallas_oficiales

(expression)  update statistics low for table aud_dot_tallas_oficiales

(expression)  update statistics low for table dot_tallas_cadetropa

(expression)  update statistics low for table aud_dot_tallas_cadetropa

(expression)  update statistics low for table dot_tallas_perscontrato

(expression)  update statistics low for table aud_dot_tallas_perscontrato

(expression)  update statistics low for table esip_mis_necesidad

(expression)  update statistics low for table aud_esip_mis_necesidad

(expression)  update statistics low for table esip_areas_mision

(expression)  update statistics low for table aud_esip_areas_mision

(expression)  update statistics low for table esip_necesidad

(expression)  update statistics low for table aud_esip_necesidad

(expression)  update statistics low for table esip_recup_capacidades

(expression)  update statistics low for table aud_esip_recup_capacidades

(expression)  update statistics low for table esip_doc_pdf2

(expression)  update statistics low for table aud_esip_doc_pdf2

(expression)  update statistics low for table esip_doc_pdf

(expression)  update statistics low for table aud_esip_doc_pdf

(expression)  update statistics low for table sie_inventarioclase2

(expression)  update statistics low for table aud_sie_inventarioclase2

(expression)  update statistics low for table tropa_movimientos

(expression)  update statistics low for table tropa_foto

(expression)  update statistics low for table tropa_disponibilidad

(expression)  update statistics low for table aud_tropa_movimientos

(expression)  update statistics low for table aud_tropa_foto

(expression)  update statistics low for table aud_tropa_disponibilidad

(expression)  update statistics low for table com_ent_sal2

(expression)  update statistics low for table aud_bin_edificaciones

(expression)  update statistics low for table seg_genero

(expression)  update statistics low for table seg_nacionalidad

(expression)  update statistics low for table seg_preguntas

(expression)  update statistics low for table seg_respuestas

(expression)  update statistics low for table seg_respuesta_correcta

(expression)  update statistics low for table solicitud_usuarios

(expression)  update statistics low for table seg_subtemas

(expression)  update statistics low for table seg_temas

(expression)  update statistics low for table usuarios_prueba

(expression)  update statistics low for table pruebas_tiempo

(expression)  update statistics low for table smm_banda

(expression)  update statistics low for table ciber_temas

(expression)  update statistics low for table aud_ciber_temas

(expression)  update statistics low for table ciber_subtemas

(expression)  update statistics low for table aud_ciber_subtemas

(expression)  update statistics low for table aud_solicitud_usuarios

(expression)  update statistics low for table ciber_preguntas

(expression)  update statistics low for table aud_ciber_preguntas

(expression)  update statistics low for table mdep_otros

(expression)  update statistics low for table aud_fag_metodo_adquisicion

(expression)  update statistics low for table aud_mdep_otros

(expression)  update statistics low for table aud_smm_banda

(expression)  update statistics low for table aud_fag_dependencia

(expression)  update statistics low for table aud_fag_condicion_rep

(expression)  update statistics low for table aud_fag_unidad_medida

(expression)  update statistics low for table aud_fag_tipo_articulos

(expression)  update statistics low for table aud_fag_seccion

(expression)  update statistics low for table permisos_bdmdn

(expression)  update statistics low for table aud_fag_estanterias

(expression)  update statistics low for table fag_metodo_adquisicion

(expression)  update statistics low for table aud_fag_columnas

(expression)  update statistics low for table fag_dependencia

(expression)  update statistics low for table aud_fag_niveles

(expression)  update statistics low for table fag_condicion_rep

(expression)  update statistics low for table aud_fag_caja

(expression)  update statistics low for table fag_unidad_medida

(expression)  update statistics low for table aud_fag_almacen

(expression)  update statistics low for table fag_tipo_articulos

(expression)  update statistics low for table aud_fag_articulos

(expression)  update statistics low for table fag_compras

(expression)  update statistics low for table aud_fag_compras

(expression)  update statistics low for table fag_articulos

(expression)  update statistics low for table aud_fag_inventario

(expression)  update statistics low for table cov_oficios

(expression)  update statistics low for table aud_cov_oficios

(expression)  update statistics low for table cov_registro

(expression)  update statistics low for table aud_cov_registro

(expression)  update statistics low for table cov_vacunas

(expression)  update statistics low for table aud_cov_vacunas

(expression)  update statistics low for table dfdes_bindustrial

(expression)  update statistics low for table aud_dfdes_bindustrial

(expression)  update statistics low for table aud_psan_sanciones

(expression)  update statistics low for table ciber_respuestas

(expression)  update statistics low for table aud_ciber_respuestas

(expression)  update statistics low for table aud_dot_asignadas

(expression)  update statistics low for table dot_asignadas_cadtropa

(expression)  update statistics low for table aud_dot_asignadas_cadtropa

(expression)  update statistics low for table fdes_fund_sold

(expression)  update statistics low for table aud_fdes_fund_sold

(expression)  update statistics low for table com_vales

(expression)  update statistics low for table con_boleta_dp

(expression)  update statistics low for table aud_con_boleta_dp

(expression)  update statistics low for table api_keys

(expression)  update statistics low for table aud_api_keys

(expression)  update statistics low for table sat_cuscar

(expression)  update statistics low for table aud_sat_cuscar

(expression)  update statistics low for table veteranos_comparacion

(expression)  update statistics low for table bin_estado

(expression)  update statistics low for table bin_inventariado

(expression)  update statistics low for table bin_valor_inmueble

(expression)  update statistics low for table bin_edificaciones

(expression)  update statistics low for table bin_obs_aprobaciones

(expression)  update statistics low for table bin_pdf_edificaciones

(expression)  update statistics low for table bin_solicitudes

(expression)  update statistics low for table aud_com_vales

(expression)  update statistics low for table evaluacion_docente_clase

(expression)  update statistics low for table aud_bin_obs_aprobaciones

(expression)  update statistics low for table aud_bin_pdf_edificaciones

(expression)  update statistics low for table aud_bin_solicitudes

(expression)  update statistics low for table aud_bin_inventariado

(expression)  update statistics low for table aud_bin_valor_inmueble

(expression)  update statistics low for table aud_bin_estado

(expression)  update statistics low for table aud_evaluacion_docente_clase

(expression)  update statistics low for table informacion_general_peisol

(expression)  update statistics low for table aud_informacion_general_peisol

(expression)  update statistics low for table evaluacion_docente

(expression)  update statistics low for table aud_evaluacion_docente

(expression)  update statistics low for table notas_finales_peisol

(expression)  update statistics low for table aud_notas_finales_peisol

(expression)  update statistics low for table maga_actividades

(expression)  update statistics low for table aud_maga_actividades

(expression)  update statistics low for table materi_peisol

(expression)  update statistics low for table aud_materi_peisol

(expression)  update statistics low for table maga_personal_asignado

(expression)  update statistics low for table aud_maga_personal_asignado

(expression)  update statistics low for table vlh_maquinaria

(expression)  update statistics low for table aud_vlh_maquinaria

(expression)  update statistics low for table vlh_validaciones_fag

(expression)  update statistics low for table aud_vlh_validaciones_fag

(expression)  update statistics low for table vlh_desc_elimina

(expression)  update statistics low for table aud_vlh_desc_elimina

(expression)  update statistics low for table vlh_retorno_cal

(expression)  update statistics low for table aud_vlh_retorno_cal

(expression)  update statistics low for table vlh_pdf

(expression)  update statistics low for table aud_vlh_pdf

(expression)  update statistics low for table vlh_pdf_embarcaciones

(expression)  update statistics low for table aud_vlh_pdf_embarcaciones

(expression)  update statistics low for table vlh_pdf_fag

(expression)  update statistics low for table aud_vlh_pdf_fag

(expression)  update statistics low for table vlh_pdf_maquinaria

(expression)  update statistics low for table aud_vlh_pdf_maquinaria

(expression)  update statistics low for table vt_mper1

(expression)  update statistics low for table vt_tab_ls_12

(expression)  update statistics low for table vt_mper3

(expression)  update statistics low for table vt_tab_ls_1

(expression)  update statistics low for table vt_tab_ls_2

(expression)  update statistics low for table vt_tab_ls_3

(expression)  update statistics low for table vt_tab_ls_4

(expression)  update statistics low for table vt_tab_ls_5

(expression)  update statistics low for table vt_tab_ls_6

(expression)  update statistics low for table vt_tab_ls_7

(expression)  update statistics low for table vt_tab_ls_8

(expression)  update statistics low for table vt_tab_ls_9

(expression)  update statistics low for table vt_tab_ls_10

(expression)  update statistics low for table vt_tab_ls_11

(expression)  update statistics low for table vt_tab_ls_13

(expression)  update statistics low for table sig_rancho

(expression)  update statistics low for table aud_sig_rancho

(expression)  update statistics low for table fin_programa

(expression)  update statistics low for table aud_fin_programa

(expression)  update statistics low for table sig_asig_grupos

(expression)  update statistics low for table fin_subproducto

(expression)  update statistics low for table aud_fin_subpro_desc

(expression)  update statistics low for table aud_fin_producto

(expression)  update statistics low for table fin_producto

(expression)  update statistics low for table aud_fin_actividades

(expression)  update statistics low for table fin_subpro_desc

(expression)  update statistics low for table sol_tarjetaunica

(expression)  update statistics low for table fin_actividades

(expression)  update statistics low for table aud_opaf_notas1

(expression)  update statistics low for table cat_permisos

(expression)  update statistics low for table aud_re22_obras

(expression)  update statistics low for table aud_sol_tarjetaunica

(expression)  update statistics low for table cond

(expression)  update statistics low for table aud_cond

(expression)  update statistics low for table far_insumos_datos

(expression)  update statistics low for table far_insumos_suma

(expression)  update statistics low for table sub_18_contrato

(expression)  update statistics low for table aud_rm_beneficiarios

(expression)  update statistics low for table rm_cuenta

(expression)  update statistics low for table aud_rm_cuenta

(expression)  update statistics low for table rm_asistencia

(expression)  update statistics low for table aud_rm_asistencia

(expression)  update statistics low for table ciber_office

(expression)  update statistics low for table aud_ciber_office

(expression)  update statistics low for table ciber_ram

(expression)  update statistics low for table aud_ciber_ram

(expression)  update statistics low for table ciber_antivirus

(expression)  update statistics low for table aud_ciber_antivirus

(expression)  update statistics low for table ciber_disco_duro

(expression)  update statistics low for table aud_ciber_disco_duro

(expression)  update statistics low for table ciber_procesador

(expression)  update statistics low for table aud_ciber_procesador

(expression)  update statistics low for table ciber_sistema_operativo

(expression)  update statistics low for table aud_ciber_sistema_operativo

(expression)  update statistics low for table ciber_evento

(expression)  update statistics low for table aud_ciber_evento

(expression)  update statistics low for table ciber_inventario

(expression)  update statistics low for table aud_ciber_inventario

(expression)  update statistics low for table tropa_beneficiarios

(expression)  update statistics low for table aud_tropa_beneficiarios

(expression)  update statistics low for table rm_historial_pagos

(expression)  update statistics low for table aud_rm_historial_pagos

(expression)  update statistics low for table aud_bd_permisos

(expression)  update statistics low for table aud_esip_unidades_ejecutoras

(expression)  update statistics low for table resumen_vacuna_ssm

(expression)  update statistics low for table aud_registro_puestos_vacunacion

(expression)  update statistics low for table registro_puestos_vacunacion

(expression)  update statistics low for table aud_resumen_vacuna_ssm

(expression)  update statistics low for table psan_sanciones

(expression)  update statistics low for table farma_farmacos

(expression)  update statistics low for table aud_sub_18_contrato

(expression)  update statistics low for table sub18_acciones

(expression)  update statistics low for table aud_sub18_acciones

(expression)  update statistics low for table sub18_boleta

(expression)  update statistics low for table aud_sub18_boleta

(expression)  update statistics low for table sub18_detalles

(expression)  update statistics low for table aud_sub18_detalles

(expression)  update statistics low for table aud_coc_area_mision

(expression)  update statistics low for table aud_coc_ope_planificada

(expression)  update statistics low for table aud_coc_coordenadas2

(expression)  update statistics low for table aud_coc_control

(expression)  update statistics low for table aud_coc_dep_orden

(expression)  update statistics low for table aud_coc_mensaje

(expression)  update statistics low for table aud_coc_metas

(expression)  update statistics low for table aud_coc_metodo_ejec

(expression)  update statistics low for table aud_coc_operaciones

(expression)  update statistics low for table aud_coc_ordenes

(expression)  update statistics low for table aud_coc_personal2

(expression)  update statistics low for table aud_coc_proposito

(expression)  update statistics low for table aud_coc_unidad_organica

(expression)  update statistics low for table aud_coc_vehiculo_rep2

(expression)  update statistics low for table aud_opaf_carrera2

(expression)  update statistics low for table aud_certificaciones

(expression)  update statistics low for table far_insumos_dependencias

(expression)  update statistics low for table aud_far_insumos_dependencias

(expression)  update statistics low for table far_insumos_datos_dependencias

(expression)  update statistics low for table aud_far_insumos_datos_dependencia
              s

(expression)  update statistics low for table fag_almacen

(expression)  update statistics low for table fag_seccion

(expression)  update statistics low for table fag_estanterias

(expression)  update statistics low for table fag_columnas

(expression)  update statistics low for table fag_niveles

(expression)  update statistics low for table fag_caja

(expression)  update statistics low for table fag_inventario

(expression)  update statistics low for table far_enfermedades

(expression)  update statistics low for table aud_far_enfermedades

(expression)  update statistics low for table far_categorias_enfermedades

(expression)  update statistics low for table aud_far_categorias_enfermedades

(expression)  update statistics low for table far_tipos_enfermedades

(expression)  update statistics low for table aud_far_tipos_enfermedades

(expression)  update statistics low for table constancias_sage

(expression)  update statistics low for table aud_constancias_sage

(expression)  update statistics low for table aud_fmper

(expression)  update statistics low for table f_cat_eliminados

(expression)  update statistics low for table aud_f_cat_eliminados

(expression)  update statistics low for table aud_lmun_conocimiento

(expression)  update statistics low for table tiro_totales

(expression)  update statistics low for table aud_tiro_totales

(expression)  update statistics low for table tiro_equipos

(expression)  update statistics low for table aud_tiro_equipos

(expression)  update statistics low for table tiro_resultados_equipo

(expression)  update statistics low for table aud_tiro_resultados_equipo

(expression)  update statistics low for table emer_julia

(expression)  update statistics low for table aud_emer_julia

(expression)  update statistics low for table emer_lisa

(expression)  update statistics low for table aud_pro_ord_gral

(expression)  update statistics low for table per_plazas_orden

(expression)  update statistics low for table aud_per_plazas_orden

(expression)  update statistics low for table pro_ord_gral_h

(expression)  update statistics low for table aud_pro_ord_gral_h

(expression)  update statistics low for table dfdes_vivibanco

(expression)  update statistics low for table aud_emer_lisa

(expression)  update statistics low for table aud_dfdes_vivibanco

(expression)  update statistics low for table pro_ord_gral

(expression)  update statistics low for table aud_hisfin

(expression)  update statistics low for table aud_tmper

(expression)  update statistics low for table aud_ep_mper

(expression)  update statistics low for table aud_vlh_tow

(expression)  update statistics low for table aud_veteranos_comparacion

(expression)  update statistics low for table aud_n_mper

(expression)  update statistics low for table aud_temp_fin_personal

(expression)  update statistics low for table aud_ipm_cart

(expression)  update statistics low for table aud_ipm_dfam_temp

(expression)  update statistics low for table aud_exp_solicitud

(expression)  update statistics low for table aud_exp_conocimiento

(expression)  update statistics low for table aud_cgsifldd

(expression)  update statistics low for table aud_tdfdes

(expression)  update statistics low for table aud_psan_boleta_restore

(expression)  update statistics low for table aud_stxparmd

(expression)  update statistics low for table aud_com_ent_sal2

(expression)  update statistics low for table fmorg

(expression)  update statistics low for table fmper

(expression)  update statistics low for table fdpue

(expression)  update statistics low for table fdfam

(expression)  update statistics low for table fdcur

(expression)  update statistics low for table slc_matrimonio

(expression)  update statistics low for table aud_slc_matrimonio

(expression)  update statistics low for table slc_licencia_temporal

(expression)  update statistics low for table aud_slc_licencia_temporal

(expression)  update statistics low for table slc_protocolo

(expression)  update statistics low for table aud_slc_protocolo

(expression)  update statistics low for table slc_sal_pais

(expression)  update statistics low for table aud_slc_sal_pais

(expression)  update statistics low for table slc_mb

(expression)  update statistics low for table aud_slc_dsal_fechas

(expression)  update statistics low for table slc_autorizado

(expression)  update statistics low for table slc_cmv

(expression)  update statistics low for table aud_slc_cmv

(expression)  update statistics low for table ciber_evaluaciones

(expression)  update statistics low for table aud_slc_autorizado

(expression)  update statistics low for table aud_slc_mb

(expression)  update statistics low for table aud_ciber_evaluaciones

(expression)  update statistics low for table ciber_detalle_evaluaciones

(expression)  update statistics low for table aud_ciber_detalle_evaluaciones

(expression)  update statistics low for table ciber_usuarios

(expression)  update statistics low for table smm_actividad

(expression)  update statistics low for table aud_ciber_usuarios

(expression)  update statistics low for table aud_smm_actividad

(expression)  update statistics low for table smm_reporte

(expression)  update statistics low for table aud_smm_reporte

(expression)  update statistics low for table opaf_carrera1

(expression)  update statistics low for table aud_opaf_carrera1

(expression)  update statistics low for table esip_fuente_financiamiento

(expression)  update statistics low for table aud_esip_fuente_financiamiento

(expression)  update statistics low for table esip_grupo_gasto

(expression)  update statistics low for table aud_esip_grupo_gasto

(expression)  update statistics low for table esip_planes_basicos

(expression)  update statistics low for table aud_esip_planes_basicos

(expression)  update statistics low for table esip_paquetes_logisticos

(expression)  update statistics low for table aud_esip_paquetes_logisticos

(expression)  update statistics low for table esip_unidad_medida

(expression)  update statistics low for table aud_esip_unidad_medida

(expression)  update statistics low for table esip_renglon_presupuestario

(expression)  update statistics low for table aud_esip_renglon_presupuestario

(expression)  update statistics low for table esip_matriz_presupuestaria

(expression)  update statistics low for table aud_esip_matriz_presupuestaria

(expression)  update statistics low for table capta_documentos

(expression)  update statistics low for table aud_asig_requisitos

(expression)  update statistics low for table capta_evaluaciones

(expression)  update statistics low for table aud_capta_documentos

(expression)  update statistics low for table capta_ingresos

(expression)  update statistics low for table aud_capta_evaluaciones

(expression)  update statistics low for table capta_evaluados

(expression)  update statistics low for table aud_capta_evaluados

(expression)  update statistics low for table amc_topico

(expression)  update statistics low for table aud_capta_ingresos

(expression)  update statistics low for table capta_tipoeva

(expression)  update statistics low for table aud_capta_requisitos

(expression)  update statistics low for table capta_feriados

(expression)  update statistics low for table aud_capta_tipoeva

(expression)  update statistics low for table municion_almacen

(expression)  update statistics low for table aud_capta_feriados

(expression)  update statistics low for table municion_calinre

(expression)  update statistics low for table aud_municion_calinre

(expression)  update statistics low for table municion_lote

(expression)  update statistics low for table aud_municion_lote

(expression)  update statistics low for table municion_situaciuon

(expression)  update statistics low for table aud_municion_situaciuon

(expression)  update statistics low for table aud_municion_almacen

(expression)  update statistics low for table municion_asentamiento

(expression)  update statistics low for table municion_fabrica

(expression)  update statistics low for table aud_municion_fabrica

(expression)  update statistics low for table asig_requisitos

(expression)  update statistics low for table tri_eventos

(expression)  update statistics low for table aud_tri_eventos

(expression)  update statistics low for table tri_etapas

(expression)  update statistics low for table aud_tri_etapas

(expression)  update statistics low for table tri_detalle

(expression)  update statistics low for table aud_tri_detalle

(expression)  update statistics low for table aud_tri_participantes

(expression)  update statistics low for table tri_participantes

(expression)  update statistics low for table aud_tri_puntaje

(expression)  update statistics low for table resp_perm_220323

(expression)  update statistics low for table tri_puntaje

(expression)  update statistics low for table coc_instituciones

(expression)  update statistics low for table aud_coc_instituciones

(expression)  update statistics low for table coc_detalle_instituciones

(expression)  update statistics low for table aud_coc_detalle_instituciones

(expression)  update statistics low for table amc_desastre_natural

(expression)  update statistics low for table aud_amc_desastre_natural

(expression)  update statistics low for table aud_amc_topico

(expression)  update statistics low for table amc_incautacion_droga

(expression)  update statistics low for table aud_amc_incautacion_droga

(expression)  update statistics low for table amc_per_capturadas

(expression)  update statistics low for table aud_amc_per_capturadas

(expression)  update statistics low for table amc_migrantes

(expression)  update statistics low for table aud_amc_migrantes

(expression)  update statistics low for table amc_movimiento_social

(expression)  update statistics low for table aud_amc_movimiento_social

(expression)  update statistics low for table amc_colores

(expression)  update statistics low for table aud_amc_colores

(expression)  update statistics low for table amc_incautacion_dinero

(expression)  update statistics low for table aud_amc_incautacion_dinero

(expression)  update statistics low for table amc_detalle_arma

(expression)  update statistics low for table aud_amc_detalle_arma

(expression)  update statistics low for table amc_detalle_municion

(expression)  update statistics low for table aud_amc_detalle_municion

(expression)  update statistics low for table amc_asesinato

(expression)  update statistics low for table aud_amc_asesinato

(expression)  update statistics low for table amc_destruccion_pista

(expression)  update statistics low for table aud_amc_destruccion_pista

(expression)  update statistics low for table amc_incautacion_armas

(expression)  update statistics low for table aud_amc_incautacion_armas

(expression)  update statistics low for table amc_nacionalidad

(expression)  update statistics low for table aud_amc_nacionalidad

(expression)  update statistics low for table amc_organizacion_mov_social

(expression)  update statistics low for table aud_amc_organizacion_mov_social

(expression)  update statistics low for table amc_tipo_movimiento_social

(expression)  update statistics low for table aud_amc_tipo_movimiento_social

(expression)  update statistics low for table amc_tipo_desastre_natural

(expression)  update statistics low for table aud_amc_tipo_desastre_natural

(expression)  update statistics low for table amc_capturas

(expression)  update statistics low for table aud_amc_capturas

(expression)  update statistics low for table amc_actividad_vinculada

(expression)  update statistics low for table aud_amc_actividad_vinculada

(expression)  update statistics low for table amc_moneda

(expression)  update statistics low for table aud_amc_moneda

(expression)  update statistics low for table amc_fenomeno_natural

(expression)  update statistics low for table aud_amc_fenomeno_natural

(expression)  update statistics low for table amc_tipo_topics

(expression)  update statistics low for table aud_amc_tipo_topics

(expression)  update statistics low for table amc_tipo_armas

(expression)  update statistics low for table aud_amc_tipo_armas

(expression)  update statistics low for table amc_transporte

(expression)  update statistics low for table aud_amc_transporte

(expression)  update statistics low for table amc_prioridad

(expression)  update statistics low for table aud_amc_prioridad

(expression)  update statistics low for table amc_tendencia

(expression)  update statistics low for table aud_amc_tendencia

(expression)  update statistics low for table amc_usuarios

(expression)  update statistics low for table aud_amc_usuarios

(expression)  update statistics low for table amc_calibre

(expression)  update statistics low for table aud_amc_calibre

(expression)  update statistics low for table amc_fuentes

(expression)  update statistics low for table aud_amc_fuentes

(expression)  update statistics low for table amc_edades

(expression)  update statistics low for table aud_amc_edades

(expression)  update statistics low for table amc_factor

(expression)  update statistics low for table aud_amc_factor

(expression)  update statistics low for table amc_delito

(expression)  update statistics low for table aud_amc_delito

(expression)  update statistics low for table amc_drogas

(expression)  update statistics low for table aud_amc_drogas

(expression)  update statistics low for table amc_sexo

(expression)  update statistics low for table aud_amc_sexo

(expression)  update statistics low for table amc_per_asesinadas

(expression)  update statistics low for table aud_amc_per_asesinadas

(expression)  update statistics low for table larm_asentamiento

(expression)  update statistics low for table aud_larm_asentamiento

(expression)  update statistics low for table coc_departamentos

(expression)  update statistics low for table aud_coc_departamentos

(expression)  update statistics low for table coc_municipios

(expression)  update statistics low for table aud_coc_municipios

(expression)  update statistics low for table coc_lugar

(expression)  update statistics low for table aud_coc_lugar

(expression)  update statistics low for table coc_detalle_lugar

(expression)  update statistics low for table aud_coc_detalle_lugar

(expression)  update statistics low for table capta_requisitos

(expression)  update statistics low for table aud_con_mdep

(expression)  update statistics low for table con_mdep

(expression)  update statistics low for table ficha_medica_asc

(expression)  update statistics low for table aud_ficha_medica_asc

(expression)  update statistics low for table tiempo_comando_asc

(expression)  update statistics low for table aud_tiempo_comando_asc

(expression)  update statistics low for table evaluaciones_perfil_asc

(expression)  update statistics low for table aud_evaluaciones_perfil_asc

(expression)  update statistics low for table opaf_notas_asc

(expression)  update statistics low for table aud_opaf_notas_asc

(expression)  update statistics low for table eva_evaluacion_asc

(expression)  update statistics low for table aud_eva_evaluacion_asc

(expression)  update statistics low for table eva_notas_asc

(expression)  update statistics low for table aud_eva_notas_asc

(expression)  update statistics low for table cursos_asc

(expression)  update statistics low for table aud_cursos_asc

(expression)  update statistics low for table creditos_asc

(expression)  update statistics low for table aud_creditos_asc

(expression)  update statistics low for table mper_asc

(expression)  update statistics low for table aud_mper_asc

(expression)  update statistics low for table observaciones_asc

(expression)  update statistics low for table aud_observaciones_asc


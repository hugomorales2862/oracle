#!/bin/bash

echo "Inicia el mantenimiento de Informix..."

if [ ! -d mantotest ]; then
    mkdir mantotest
fi

onstat -d > /opt/informix/mantotest/storage.txt
onmode -we /opt/informix/mantotest/onconfig.exp
onstat -g cfg > /opt/informix/mantotest/instance_cfg.txt
onstat -g seg > /opt/informix/mantotest/memory.txt
onstat -g sql > /opt/informix/mantotest/sql.txt
onstat -g ses > /opt/informix/mantotest/session.txt
onstat -g sch > /opt/informix/mantotest/process.txt
onstat - > /opt/informix/mantotest/onstat.txt
onstat -p | grep -A 1 ckpwaits > /opt/informix/mantotest/ckpwaits.txt

dbaccess <<EOSQL > /opt/informix/mantotest/databases.txt
DATABASE sysmaster;
select sysdatabases.name, sysdatabases.owner, sysdbspaces.name from sysdbspaces,sysdatabases where partdbsnum(sysdatabases.partnum) = sysdbspaces.dbsnum;
EOSQL

dbaccess <<EOSQL2 >> /opt/informix/mantotest/databases.txt
DATABASE sysmaster;
SELECT
    dbsname,
    SUM(ti_nptotal * ti_pagesize / 1024/1024) :: INT AS Mb_alloc,
    SUM(ti_npused  * ti_pagesize / 1024/1024) :: INT AS Mb_used
FROM
    sysdatabases AS d,
    systabnames AS n,
    systabinfo AS i
WHERE n.dbsname = d.name
AND ti_partnum = n.partnum
GROUP BY 1
ORDER BY 1;
EOSQL2

dbaccess <<EOSQL3 >> /opt/informix/mantotest/memory.txt
DATABASE sysmaster;
select dbinfo ('utc_to_datetime', sh_boottime) from sysshmvals; 
EOSQL3

dbaccess <<EOSQL4 >> /opt/informix/mantotest/storage.txt
DATABASE sysmaster;
select name[1,8] dbspace,
sum(chksize) Pages_size,
sum(chksize) -sum(nfree) Pages_used,
sum(nfree) Pages_free,
round ((sum(nfree)) / (sum(chksize)) * 100, 2) percent_free
from sysdbspaces d, syschunks c
where d.dbsnum = c.dbsnum
group by 1
order by 1;
EOSQL4

dbaccess <<EOSQL5 >> /opt/informix/mantotest/storage.txt
DATABASE sysmaster;
SELECT d.name[1,18] dbspace,      
        fname [1,22],  
        sum(pagesread) dreads,
        sum(pageswritten) dwrites
   FROM syschkio c, syschunks k, sysdbspaces d
  WHERE d.dbsnum = k.dbsnum      
    AND k.chknum = c.chunknum
GROUP BY 1, 2
ORDER BY 3 desc;
EOSQL5

cd /opt/informix/mantotest/
chmod 766 *
chmod 755 *.sql

echo "Fin el mantenimiento de Informix..."
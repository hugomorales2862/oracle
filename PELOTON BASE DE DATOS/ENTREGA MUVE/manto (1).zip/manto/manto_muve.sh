#/bin/bash

echo "Inicia el mantenimiento de Informix..."

if [ ! -d manto ]; then
mkdir manto
fi

onstat -d > /opt/informix/manto/storage.txt
onmode -we /opt/informix/manto/onconfig.exp
onstat -g cfg > /opt/informix/manto/instance_cfg.txt
onstat -g seg > /opt/informix/manto/memory.txt
onstat -g sql > /opt/informix/manto/memory.txt
onstat -g ses > /opt/informix/manto/session.txt
onstat -g sch > /opt/informix/manto/process.txt
onstat - >> /opt/informix/manto/memory.txt
onstat -p |grep -A 1 ckpwaits > /opt/informix/manto/ckpwaits.txt

dbaccess > /opt/informix/manto/databases.txt << EOSQL
 DATABASE sysmaster;
select sysdatabases.name, sysdatabases.owner, sysdbspaces.name  
            from sysdbspaces,sysdatabases  
            where partdbsnum(sysdatabases.partnum) = sysdbspaces.dbsnum;
EOSQL

dbaccess >> /opt/informix/manto/databases.txt << EOSQL2
 DATABASE sysmaster;
SELECT
    dbsname,
    SUM(ti_nptotal * ti_pagesize / 1024/1024) :: INT AS Mb_alloc,
    SUM(ti_npused  * ti_pagesize / 1024/1024) :: INT AS Mb_used
FROM
    sysdatabases AS d,
    systabnames AS n,
    systabinfo AS i
WHERE n.dbsname = d.name
AND ti_partnum = n.partnum
GROUP BY 1
ORDER BY 1;
EOSQL2

dbaccess >> /opt/informix/manto/memory.txt << EOSQL3
 DATABASE sysmaster;
select dbinfo ('utc_to_datetime', sh_boottime) from sysshmvals; 
EOSQL3

dbaccess >> /opt/informix/manto/storage.txt << EOSQL4
 DATABASE sysmaster;
select name[1,8] dbspace,
sum(chksize) Pages_size,
sum(chksize) -sum(nfree) Pages_used,
sum(nfree) Pages_free,
round ((sum(nfree)) / (sum(chksize)) * 100, 2) percent_free
from sysdbspaces d, syschunks c
where d.dbsnum = c.dbsnum
group by 1
order by 1;
EOSQL4

dbaccess >> /opt/informix/manto/storage.txt << EOSQL5
 DATABASE sysmaster;
 SELECT d.name[1,18] dbspace,      
        fname [1,22],  
        sum(pagesread) dreads,
        sum(pageswritten) dwrites
   FROM syschkio c, syschunks k, sysdbspaces d
  WHERE d.dbsnum = k.dbsnum      
    AND k.chknum = c.chunknum
GROUP BY 1, 2
ORDER BY 3 desc;
EOSQL5

dbaccess > /opt/informix/manto/defragment.txt << EOSQL6
 DATABASE sysmaster;
select dbsname[1,20],tabname[1,20], count(*) num_of_extents, sum( pe_size ) total_size
from systabnames, sysptnext
where partnum = pe_partnum
group by 1, 2 
having count(*) > 40
order by 3 desc, 4 desc;
EOSQL6

dbaccess > /opt/informix/manto/locks.txt << EOSQL7
 DATABASE sysmaster;
select owner, username, hostname, dbsname, tabname, type
  from syssessions s, syslocks l
 where sid  = owner
   and tabname not like "sys%";
EOSQL7

dbaccess > /opt/informix/manto/updsts_mdn.sql << EOSQL8
database mdn;
select "update statistics low for table " || trim (tabname) 
from systables where tabid > 99 
and tabtype = "T";
EOSQL8

dbaccess > /opt/informix/manto/updsts_sicol.sql << EOSQL9
database sicol;
select "update statistics low for table " || trim (tabname) 
from systables where tabid > 99 
and tabtype = "T";
EOSQL9

dbaccess > /opt/informix/manto/usersifmx.txt << EOSQL10
database sysmaster;
select * from sysusers;
EOSQL10

dbaccess > /opt/informix/manto/updsts_sysmaster.sql << EOSQL11
database sysmaster;
select "update statistics low for table " || trim (tabname) 
from systables where tabid > 99 
and tabtype = "T";
EOSQL11

cd /
find / -name *.4go > /opt/informix/manto/output_4gl.txt
find / -name *.4gl>> /opt/informix/manto/output_4gl.txt
find / -name *.4gi>> /opt/informix/manto/output_4gl.txt

echo "Fin el mantenimiento de Informix..."
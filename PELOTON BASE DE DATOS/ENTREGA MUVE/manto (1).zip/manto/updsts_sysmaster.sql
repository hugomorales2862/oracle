


(expression)  update statistics low for table sysdbspartn

(expression)  update statistics low for table systabnames

(expression)  update statistics low for table sysrawdsk

(expression)  update statistics low for table syspaghdr

(expression)  update statistics low for table sysslttab

(expression)  update statistics low for table syssltdat

(expression)  update statistics low for table syschfree

(expression)  update statistics low for table syssymtab

(expression)  update statistics low for table sysproftab

(expression)  update statistics low for table sysptnhdr

(expression)  update statistics low for table sysptnkey

(expression)  update statistics low for table sysptnext

(expression)  update statistics low for table sysptncol

(expression)  update statistics low for table sysptnbit

(expression)  update statistics low for table sysactptnhdr

(expression)  update statistics low for table sysrstcb

(expression)  update statistics low for table systxptab

(expression)  update statistics low for table sysxatab

(expression)  update statistics low for table syslcktab

(expression)  update statistics low for table sysbufpool

(expression)  update statistics low for table sysbufhdr

(expression)  update statistics low for table sysdbstab

(expression)  update statistics low for table syschktab

(expression)  update statistics low for table sysmchktab

(expression)  update statistics low for table syschktab_fast

(expression)  update statistics low for table sysmchktab_fast

(expression)  update statistics low for table syslogfil

(expression)  update statistics low for table sysbtcreq

(expression)  update statistics low for table systraces

(expression)  update statistics low for table sysptntab

(expression)  update statistics low for table sysshmem

(expression)  update statistics low for table sysshmhdr

(expression)  update statistics low for table syscfgtab

(expression)  update statistics low for table sysscblst

(expression)  update statistics low for table systcblst

(expression)  update statistics low for table sysvplst

(expression)  update statistics low for table sysdrcb

(expression)  update statistics low for table syscdrq

(expression)  update statistics low for table syscdrtx

(expression)  update statistics low for table syscdrs

(expression)  update statistics low for table syscdrprog

(expression)  update statistics low for table syscdrrecvqprog

(expression)  update statistics low for table syscdrcntrlqprog

(expression)  update statistics low for table syscdrsend_txn

(expression)  update statistics low for table sysreorgops

(expression)  update statistics low for table syscdrack_txn

(expression)  update statistics low for table syscdrctrl_txn

(expression)  update statistics low for table syscdrsync_txn

(expression)  update statistics low for table syscdrrecv_txn

(expression)  update statistics low for table syscdrsend_buf

(expression)  update statistics low for table syscdrack_buf

(expression)  update statistics low for table syscdrctrl_buf

(expression)  update statistics low for table syscdrsync_buf

(expression)  update statistics low for table syscdrrecv_buf

(expression)  update statistics low for table syscdrrecv_stats

(expression)  update statistics low for table syscdrlatency

(expression)  update statistics low for table syscdrtsapply

(expression)  update statistics low for table syscdr_rqm

(expression)  update statistics low for table syscdr_state

(expression)  update statistics low for table syscdr_ddr

(expression)  update statistics low for table syscdr_nif

(expression)  update statistics low for table syscdr_rcv

(expression)  update statistics low for table syscdr_atsdir

(expression)  update statistics low for table syscdr_risdir

(expression)  update statistics low for table syscdr_ats

(expression)  update statistics low for table syscdr_ris

(expression)  update statistics low for table syscdr_rqmstamp

(expression)  update statistics low for table syscdr_rqmhandle

(expression)  update statistics low for table syscompdicts_full

(expression)  update statistics low for table sysplog

(expression)  update statistics low for table systwaits

(expression)  update statistics low for table sysmtxlst

(expression)  update statistics low for table sysconlst

(expression)  update statistics low for table syspoollst

(expression)  update statistics low for table sysseglst

(expression)  update statistics low for table sysdic

(expression)  update statistics low for table sysdsc

(expression)  update statistics low for table sysprc

(expression)  update statistics low for table syssqscb

(expression)  update statistics low for table syssdblock

(expression)  update statistics low for table sysconblock

(expression)  update statistics low for table sysopendb

(expression)  update statistics low for table syssqlcacheprof

(expression)  update statistics low for table syssqlstat

(expression)  update statistics low for table syslrus

(expression)  update statistics low for table syscheckpoint

(expression)  update statistics low for table sysnetworkio

(expression)  update statistics low for table sysnetglobal

(expression)  update statistics low for table sysnetclienttype

(expression)  update statistics low for table sysenv

(expression)  update statistics low for table sysenvses

(expression)  update statistics low for table sysonlinelog

(expression)  update statistics low for table sysbaract_log

(expression)  update statistics low for table sysipl

(expression)  update statistics low for table syssmx

(expression)  update statistics low for table syssmxses

(expression)  update statistics low for table syssrcrss

(expression)  update statistics low for table systrgrss

(expression)  update statistics low for table sysrsslog

(expression)  update statistics low for table syssrcsds

(expression)  update statistics low for table systrgsds

(expression)  update statistics low for table syscluster

(expression)  update statistics low for table sysrepstats

(expression)  update statistics low for table sysrepevtreg

(expression)  update statistics low for table sysha_type

(expression)  update statistics low for table sysha_lagtime

(expression)  update statistics low for table sysha_workload

(expression)  update statistics low for table syscmsmtab

(expression)  update statistics low for table syscmsmunit

(expression)  update statistics low for table syscmsmsla

(expression)  update statistics low for table sysdual

(expression)  update statistics low for table syssqlhosts

(expression)  update statistics low for table syslicenseinfo

(expression)  update statistics low for table sysmachineinfo

(expression)  update statistics low for table sysiohistory

(expression)  update statistics low for table syslowmemorymgr

(expression)  update statistics low for table sysstoragemgr

(expression)  update statistics low for table syssqltrace_info

(expression)  update statistics low for table syssqltrace

(expression)  update statistics low for table syssqltrace_iter

(expression)  update statistics low for table syssqltrace_hvar

(expression)  update statistics low for table syssesappinfo

(expression)  update statistics low for table sysshmvals

(expression)  update statistics low for table sysmgminfo

(expression)  update statistics low for table sysmgmgates

(expression)  update statistics low for table sysmgmquery

(expression)  update statistics low for table sysadtinfo

(expression)  update statistics low for table syscrtadt

(expression)  update statistics low for table sysproxydistributors

(expression)  update statistics low for table sysproxyagents

(expression)  update statistics low for table sysproxysessions

(expression)  update statistics low for table sysproxytxns

(expression)  update statistics low for table sysproxytxnops

(expression)  update statistics low for table sysfileinfo

(expression)  update statistics low for table sysaqt

(expression)  update statistics low for table sysaqtjp

(expression)  update statistics low for table sysprobetables

(expression)  update statistics low for table sysprobecolumns

(expression)  update statistics low for table sysprobejds

(expression)  update statistics low for table sysprobejps

(expression)  update statistics low for table flags_text

(expression)  update statistics low for table smi_build_status

(expression)  update statistics low for table logmessage

(expression)  update statistics low for table sysaudit

(expression)  update statistics low for table sysextspaces

